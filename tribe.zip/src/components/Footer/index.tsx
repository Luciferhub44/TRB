import React, { FC } from "react";
import DiscordFillIcon from "remixicon-react/DiscordFillIcon";
import MediumFillIcon from "remixicon-react/MediumFillIcon";
import InstagramFillIcon from "remixicon-react/InstagramFillIcon";
import TwitterFillIcon from "remixicon-react/TwitterFillIcon";
import { useHistory, useLocation } from "react-router-dom";

interface FooterProps {}

const Footer: FC<FooterProps> = () => {
  const history = useHistory();
  const location = useLocation();

  return (
    <footer
      className="max-w-[1200px] mr-auto ml-auto px-[20px]  text-theme-grey "
      style={{ paddingBottom: 50 }}
    >
      <div className="w-full flex flex-col md:flex-row items-center gap-[20px] md:gap-0 justify-between">
        <div className="flex gap-[35px]">
          <div className="flex gap-[15px]">
            <a
              href="https://discord.gg/AfymTZDXN9"
              target="_blank"
              rel="noreferrer"
            >
              <DiscordFillIcon />
            </a>
            <a
              href="https://twitter.com/tribeodyssey"
              target="_blank"
              rel="noreferrer"
            >
              <TwitterFillIcon />
            </a>
            <a
              href="https://www.instagram.com/tribe.odyssey/"
              target="_blank"
              rel="noreferrer"
            >
              <InstagramFillIcon />
            </a>
            <a
              href="https://medium.com/@0xapenft"
              target="_blank"
              rel="noreferrer"
            >
              <MediumFillIcon />
            </a>
          </div>
        </div>
        <div className="flex gap-[32px]">
          <a
            href="https://apeshop.tribeodyssey.com/"
            target="_blank"
            rel="noreferrer"
          >
            Ape shop
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
