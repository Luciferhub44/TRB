/* eslint-disable jsx-a11y/anchor-is-valid */
import { FC, useContext, useState } from "react";
import { useHistory, useLocation } from "react-router-dom";
import Button from "../Button";
import MenuFillIcon from "remixicon-react/MenuFillIcon";
import CloseLineIcon from "remixicon-react/CloseLineIcon";
import { Menu } from "@headlessui/react";
import MarketPlaceDropdown from "../MarketPlaceDropdown";
import ProfileDropdown from "../ProfileDropdwon";
import AssetDropdown from "../AssetDropdown";
import { InstaIcon, MediumIcon, TwitterIcon } from "../../assets/icons";
import StakingDropdown from "../StakingDropdown";
import { useWalletConnect, useWeb3React } from "../../hooks/useWeb3React";

interface HeaderProps {}

const Header: FC<HeaderProps> = () => {
  const { account } = useWeb3React();
  const { openConnectModal } = useWalletConnect();

  const links: { label: string; path: string }[] = [
    // { label: "About", path: "/about" },
    // { label: "Claim", path: "/claim" },
  ];

  const history = useHistory();
  const location = useLocation();
  const [visible, setVisible] = useState(false);

  return (
    <header
      className="border-b border-[#80839a80] fixed top-0 left-0 w-screen bg-theme-dark bg-opacity-50 backdrop-blur backdrop-filter  firefox:bg-opacity-90 h-[80px]"
      style={{ zIndex: 9999 }}
    >
      <div
        className={`md:hidden fixed top-0 h-screen w-screen z-[1000] bg-gradient-dark transition-all ease-in-out ${
          visible ? "left-0" : "left-[100%]"
        }`}
      >
        <div
          onClick={() => setVisible(false)}
          className="absolute top-[20px] right-[30px] flex cursor-pointer text-gradient"
        >
          <span>Close</span>
          <CloseLineIcon className="text-theme-orange" />
        </div>
        <div className="flex flex-col items-center py-[100px] justify-between h-full">
          <div className="flex flex-col gap-[50px] items-center">
            {links.map((el, i) => {
              return (
                <div
                  onClick={() => {
                    history.push(el.path || "/");
                    setVisible(false);
                  }}
                  key={i}
                  className={`text-[20px] hover:text-theme-orange cursor-pointer ${
                    location.pathname === el.path ? "text-gradient" : ""
                  }`}
                >
                  {el.label}
                </div>
              );
            })}
            <AssetDropdown />
            <MarketPlaceDropdown />
            <StakingDropdown />
            <div className="relative">
              <Menu>
                <Menu.Button
                  className={`mx-[10px] flex text-theme-grey w-[100px]`}
                >
                  <a className="hover:text-theme-red" href="/council">
                    The Council
                  </a>
                </Menu.Button>
              </Menu>
            </div>
          </div>
          {location.pathname === "/home" ? (
            <a
              href="https://discord.gg/AfymTZDXN9"
              className="discordbutton"
              rel="noreferrer"
              target="_blank"
            >
              <Button className="mx-[24px]">Join Discord</Button>
            </a>
          ) : account ? (
            <ProfileDropdown />
          ) : (
            <Button onClick={openConnectModal} className="mx-[24px] ">
              Connect wallet
            </Button>
          )}
        </div>
      </div>

      <div className="flex justify-between items-center max-w-[1200px] mr-auto ml-auto px-[20px] h-[80px]">
        <div className="h-[40px] md:flex items-center hidden">
          <img
            onClick={() => history.push("/")}
            className={`object-cover h-full w-full cursor-pointer ${"mr-10"}`}
            src="/assets/logo.png"
            alt=""
          />

          <AssetDropdown />
          <MarketPlaceDropdown />
          <StakingDropdown />

          <div className="relative">
            <Menu>
              <Menu.Button
                className={`mx-[10px] flex text-theme-grey w-[100px]`}
              >
                <a className="hover:text-theme-red" href="/council">
                  The Council
                </a>
              </Menu.Button>
            </Menu>
          </div>
        </div>

        <div className="flex gap-2 cursor-pointer md:hidden">
          <img
            onClick={() => history.push("/")}
            className={`object-cover h-full w-full cursor-pointer ${"mr-10"}`}
            src="/assets/logo.png"
            alt=""
          />
        </div>

        <div
          className="flex gap-2 cursor-pointer md:hidden"
          onClick={() => setVisible(true)}
        >
          <a>
            <MenuFillIcon className="text-theme-orange scale-x-150" />
          </a>
        </div>

        <div className="md:flex items-center hidden h-full">
          {location.pathname != "/home" &&
            links.map((el, i) => (
              <div
                onClick={() => history.push(el.path)}
                className={`h-full px-[24px] flex items-center text-theme-grey cursor-pointer hover:opacity-80 transition-all border-b-2  ${
                  location.pathname === el.path
                    ? "border-theme-red text-white"
                    : "border-transparent"
                }`}
                key={i}
              >
                {el.label}
              </div>
            ))}
          {/* {location.pathname !== "/home" && <AssetDropdown />}
          {location.pathname !== "/home" && <MarketPlaceDropdown />} */}

          <>
            <div className="socialicons">
              <a
                href="https://twitter.com/tribeodyssey"
                className="discordbutton"
                rel="noreferrer"
                target="_blank"
              >
                <TwitterIcon />
              </a>
              <a
                href="https://www.instagram.com/tribe.odyssey/"
                className="discordbutton"
                rel="noreferrer"
                target="_blank"
              >
                <InstaIcon />
              </a>
              <a
                href="https://medium.com/@0xapenft"
                className="discordbutton"
                rel="noreferrer"
                target="_blank"
              >
                <MediumIcon />
              </a>
            </div>
            {!(
              location.pathname.includes("/account") ||
              location.pathname.includes("/ens") ||
              location.pathname.includes("/staking") ||
              location.pathname.includes("/admin") ||
              location.pathname.includes("/raffle") ||
              location.pathname.includes("/raffles")
            ) ? (
              <a
                href="https://discord.gg/AfymTZDXN9"
                className="discordbutton"
                rel="noreferrer"
                target="_blank"
              >
                <Button className="mx-[24px]">Join Discord</Button>
              </a>
            ) : account ? (
              <ProfileDropdown />
            ) : (
              <Button onClick={openConnectModal} className="mx-[24px]">
                Connect wallet
              </Button>
            )}
          </>
        </div>
      </div>
    </header>
  );
};

export default Header;
