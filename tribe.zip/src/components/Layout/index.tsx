import React, { FC, useEffect, useState } from "react";
import GlobalContext from "../../contexts/GlobalContext";
import Footer from "../Footer";
import Header from "../Header";
import { useHistory } from "react-router-dom";
import { useAccount } from "wagmi";

interface LayoutProps {
  children: any;
}

const Layout: FC<LayoutProps> = ({ children }) => {
  const [state, setState] = useState({ open: false, auth: false, trigger: 0 });

  const history = useHistory();

  const { isConnected } = useAccount();
  useEffect(() => {
    if (isConnected) {
      const first = window.localStorage.getItem("wagmi.connect");
      if (first !== "true") {
        window.localStorage.setItem("wagmi.connect", "true");
        history.push("/account");
      }
    }
  }, [isConnected, history]);

  return (
    <GlobalContext.Provider value={{ state, setState }}>
      <Header />
      <main className="mainlayout max-w-[1200px] mr-auto ml-auto px-[20px] py-[100px] pt-[150px] min-h-[90vh]">
        {children}
      </main>
      <Footer />
    </GlobalContext.Provider>
  );
};

export default Layout;
