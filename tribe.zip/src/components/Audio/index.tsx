import React, { FC } from "react";
import useAudioPlayer from "../../hooks/useAudioPlayer.js";

interface AudioProps {
  title: string;
  src: string;
}

const Audio: FC<AudioProps> = ({ title, src }) => {
  const { playing, setPlaying, setClickedTime } = useAudioPlayer(title);

  return (
    <div className="flex gap-[20px]  flex-col border border-[#80839a80] rounded-lg p-[20px] ens-box-gradient w-[300px] sm:w-[400px]">
      <div className="player flex-row flex">
        <audio id={title} loop={false}>
          <source src={src} />
          Your browser does not support the <code>audio</code> element.
        </audio>
        <div className="controls">
          <button onClick={() => setPlaying(true)}>
            <img src={"../../assets/play.png"} alt="" className="w-[45px]" />
          </button>

          <button onClick={() => setPlaying(false)}>
            <img
              src={"../../assets/pause.png"}
              alt=""
              className="w-[45px] ml-1"
            />
          </button>

          <button
            onClick={() => {
              setPlaying(false);
              setClickedTime(0);
            }}
          >
            <img
              src={"../../assets/stop.png"}
              alt=""
              className="w-[45px] ml-1"
            />
          </button>
        </div>
      </div>
      <div className="flex flex-row justify-between">
        <p>{title}</p>
        <a className="flex items-center text-[#B91D1D]" href={src} download>
          Download{"  "}
          {/* <img
            src={require("../../assets/download.png").default}
            alt=""
            className="ml-1"
          /> */}
        </a>
      </div>
    </div>
  );
};

export default Audio;
