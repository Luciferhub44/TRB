import React, { FC, useState } from "react";
import ArrowDropDownLineIcon from "remixicon-react/ArrowDropDownLineIcon";
import ArrowDropUpLineIcon from "remixicon-react/ArrowDropUpLineIcon";

interface DiscloseProps {
  title?: any;
  body?: any;
}

const Disclose: FC<DiscloseProps> = ({ title, body }) => {
  const [open, setOpen] = useState(false);

  return (
    <div className="w-full p-[20px] flex flex-col gap-[40px] border border-theme-grey rounded-lg">
      <div
        onClick={() => setOpen(!open)}
        className="flex justify-between items-center cursor-pointer"
      >
        <span className="text-[20px] text-bold ">{title}</span>
        {open ? <ArrowDropUpLineIcon /> : <ArrowDropDownLineIcon />}
      </div>
      {open && <div className="text-theme-grey">{body}</div>}
    </div>
  );
};

export default Disclose;
