/* eslint-disable react/jsx-no-target-blank */
import { FC, useContext } from "react";
import { Menu } from "@headlessui/react";

import ArrowDropDownLineIcon from "remixicon-react/ArrowDropDownLineIcon";
import ArrowDropUpLineIcon from "remixicon-react/ArrowDropUpLineIcon";
import LogoutBoxRLineIcon from "remixicon-react/LogoutBoxRLineIcon";
import AccountCircleLineIcon from "remixicon-react/AccountCircleLineIcon";
import { connectorLocalStorageKey } from "../../hooks";
import { shortenAddress } from "../../utils";
import useAuth from "../../hooks/useAuth";
import { useHistory, useLocation } from "react-router-dom";
import { useWeb3React } from "../../hooks/useWeb3React";
import useUserStaked from "../../hooks/useUserStaked";
import GlobalContext from "../../contexts/GlobalContext";

interface ProfileDropdownProps {}

const ProfileDropdown: FC<ProfileDropdownProps> = () => {
  const { account } = useWeb3React();
  const { logout } = useAuth();
  const location = useLocation();
  const history = useHistory();
  const context: any = useContext(GlobalContext);

  const { userStaked } = useUserStaked(context.state.trigger || 0);

  return (
    <Menu>
      {({ open }) => (
        <div className="relative menubtnmobile">
          <Menu.Button
            className={`mx-[20px]  flex text-white border border-theme-red px-[20px] py-[12px] rounded-lg btnLogout`}
          >
            <p>{shortenAddress(account || "")}</p>
            {open ? (
              <ArrowDropUpLineIcon className="cursor-pointer" />
            ) : (
              <ArrowDropDownLineIcon className="cursor-pointer" />
            )}
          </Menu.Button>
          <Menu.Items
            className={
              "absolute top-0 left-0 translate-x-[20px] w-[180px] translate-y-[65px] flex flex-col bg-theme-dark border border-theme-grey rounded  gap-2"
            }
          >
            <Menu.Item>
              <>
                {location.pathname.includes("/staking") ||
                location.pathname.includes("/account") ||
                location.pathname.includes("/raffle") ||
                location.pathname.includes("/raffles") ? (
                  <>
                    <div className="ddrow">
                      <b>Apes Staked</b>
                      {userStaked?.staked_count || 0} Apes
                    </div>
                    <div className="ddrow">
                      <b>24hr Points Earned</b>
                      {userStaked?.daily_points || 0} Points
                    </div>
                    <div className="ddrow">
                      <b>Total Earned</b>
                      {(userStaked?.points || 0).toFixed(2)} Points
                    </div>
                  </>
                ) : null}
                <div
                  onClick={() => {
                    history.push("/account");
                  }}
                  className="px-[20px] flex gap-3 py-[12px] cursor-pointer hover:opacity-70"
                  style={{ borderTop: "1px solid rgba(128, 131, 154, 0.50)" }}
                >
                  <AccountCircleLineIcon /> <span>Profile</span>
                </div>
                <div
                  onClick={() => {
                    logout();
                    window.localStorage.removeItem(connectorLocalStorageKey);
                  }}
                  className="px-[20px] flex gap-3 py-[12px] cursor-pointer hover:opacity-70"
                  style={{ borderTop: "1px solid rgba(128, 131, 154, 0.50)" }}
                >
                  <LogoutBoxRLineIcon /> <span>Logout</span>
                </div>
              </>
            </Menu.Item>
          </Menu.Items>
        </div>
      )}
    </Menu>
  );
};

export default ProfileDropdown;
