import React, { FC, useContext } from "react";
import { Dialog } from "@headlessui/react";
import CloseFillIcon from "remixicon-react/CloseFillIcon";
import Checkbox from "../Checkbox";
import GlobalContext from "../../contexts/GlobalContext";
import useAuth from "../../hooks/useAuth";

interface ConnectWalletProps {}

const ConnectWallet: FC<ConnectWalletProps> = () => {
  const context: any = useContext(GlobalContext);
  const state = context.state;
  const setState = context.setState;
  const open = state.open;

  const { login } = useAuth();

  const toggleOpen = () => {
    setState((prevState: any) => ({ ...prevState, open: !prevState.open }));
  };

  // const onAuth = (connector: ConnectorNames) => {
  //   login(connector);
  //   window.localStorage.setItem(connectorLocalStorageKey, connector);
  //   setState((prevState: any) => ({ ...prevState, open: false }));
  // };

  return (
    <>
      {open && (
        <div
          onClick={toggleOpen}
          className="fixed top-0 left-0 h-full w-full inset-0 bg-black bg-opacity-90 z-[500]"
        />
      )}
      <Dialog
        className={
          "top-[50%] z-[501] left-[50%] bg-theme-dark p-[20px] fixed translate-x-[-50%] translate-y-[-50%] rounded-lg  max-w-[450px] w-full"
        }
        open={open}
        onClose={toggleOpen}
      >
        <Dialog.Panel>
          <Dialog.Title
            className={"flex justify-between items-center mb-[40px]"}
          >
            <h3>Connect your wallet</h3>
            <CloseFillIcon
              className="cursor-pointer"
              onClick={() => toggleOpen()}
            />
          </Dialog.Title>
          {/* <div className={"flex flex-col gap-[20px]"}>
            <Checkbox
              onClick={() => {
                onAuth(ConnectorNames.Injected);
              }}
              type="full"
            >
              <img className="w-[24px]" src="/assets/metamask.png" alt="" />
              <span>Metamask</span>
            </Checkbox>
            <Checkbox
              onClick={() => {
                onAuth(ConnectorNames.Portis);
              }}
              type="full"
            >
              <img className="w-[18px]" src="/assets/portis.png" alt="" />
              <span>Portis</span>
            </Checkbox>
            <Checkbox
              onClick={() => {
                onAuth(ConnectorNames.WalletConnect);
              }}
              type="full"
            >
              <img
                className="w-[24px]"
                src="/assets/WalletConnect.png"
                alt=""
              />
              <span>WalletConnect</span>
            </Checkbox>
          </div> */}
        </Dialog.Panel>
      </Dialog>
    </>
  );
};

export default ConnectWallet;
