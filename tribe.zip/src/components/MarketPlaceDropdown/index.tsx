/* eslint-disable react/jsx-no-target-blank */
import React, { FC } from "react";
import { Menu } from "@headlessui/react";

import ArrowDropDownLineIcon from "remixicon-react/ArrowDropDownLineIcon";
import ArrowDropUpLineIcon from "remixicon-react/ArrowDropUpLineIcon";

interface MarketPlaceDropdownProps {}

const MarketPlaceDropdown: FC<MarketPlaceDropdownProps> = () => {
  const links = [
    {
      label: "Ape Shop",
      link: "https://apeshop.tribeodyssey.com/",
    },
    {
      label: "Opensea",
      link: "https://opensea.io/collection/tribe-odyssey",
    },
    {
      label: "Looksrare",
      link: "https://looksrare.org/collections/0x77F649385cA963859693C3d3299D36dfC7324EB9",
    },
    {
      label: "X2Y2",
      link: "https://x2y2.io/collection/tribe-odyssey/",
    },
  ];

  return (
    <Menu>
      {({ open }) => (
        <div className="relative">
          <Menu.Button
            className={`mx-[10px]  flex ${
              open ? "text-white" : "text-theme-grey"
            }`}
          >
            <p>Marketplace</p>
            {open ? (
              <ArrowDropUpLineIcon className="cursor-pointer" />
            ) : (
              <ArrowDropDownLineIcon className="cursor-pointer" />
            )}
          </Menu.Button>
          <Menu.Items
            className={
              "absolute top-0 left-0 translate-x-[20px] w-[180px] translate-y-[45px] flex flex-col bg-theme-dark border border-theme-grey rounded p-4 gap-2 z-10"
            }
          >
            {links.map((el, i) => {
              return (
                <Menu.Item key={i}>
                  <a
                    className="hover:text-theme-red"
                    target={"_blank"}
                    href={el.link}
                  >
                    {el.label}
                  </a>
                </Menu.Item>
              );
            })}
          </Menu.Items>
        </div>
      )}
    </Menu>
  );
};

export default MarketPlaceDropdown;
