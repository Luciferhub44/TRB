import React, { FC } from "react";

interface InputProps {
  placeholder?: string;
  value?: string;
  onChange?: any;
}

const Input: FC<InputProps> = ({ placeholder, value, onChange }) => {
  return (
    <input
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      type="text"
      className="h-[50px] rounded-lg border border-theme-grey w-full bg-transparent outline-none text-white px-4 hover:border-[#E5E5E5] focus:border-[#E5E5E5]"
    />
  );
};

export default Input;
