/* eslint-disable react/jsx-no-target-blank */
import React, { FC } from "react";
import { Menu } from "@headlessui/react";

import ArrowDropDownLineIcon from "remixicon-react/ArrowDropDownLineIcon";
import ArrowDropUpLineIcon from "remixicon-react/ArrowDropUpLineIcon";

interface AssetDropdownProps {}

const AssetDropdown: FC<AssetDropdownProps> = () => {
  const links = [
    {
      label: "4K Tribe",
      link: "/4ktribe",
    },
    {
      label: "Wallpaper",
      link: "/wallpaper",
    },
    {
      label: "ENS",
      link: "/ens",
    },
    {
      label: "Tribal Beats",
      link: "/beats",
    },
  ];

  return (
    <Menu>
      {({ open }) => (
        <div className="relative">
          <Menu.Button
            className={`mx-[10px]  flex ${
              open ? "text-white" : "text-theme-grey"
            }`}
          >
            <p>Assets</p>
            {open ? (
              <ArrowDropUpLineIcon className="cursor-pointer" />
            ) : (
              <ArrowDropDownLineIcon className="cursor-pointer" />
            )}
          </Menu.Button>
          <Menu.Items
            className={
              "absolute top-0 left-0 translate-x-[20px] w-[180px] translate-y-[45px] flex flex-col bg-theme-dark border border-theme-grey rounded p-4 gap-2 z-10"
            }
          >
            {links.map((el, i) => {
              return (
                <Menu.Item key={i}>
                  <a className="hover:text-theme-red" href={el.link}>
                    {el.label}
                  </a>
                </Menu.Item>
              );
            })}
          </Menu.Items>
        </div>
      )}
    </Menu>
  );
};

export default AssetDropdown;
