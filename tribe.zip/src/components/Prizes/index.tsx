import React, { FC, useState } from "react";
import ArrowDropDownLineIcon from "remixicon-react/ArrowDropDownLineIcon";
import ArrowDropUpLineIcon from "remixicon-react/ArrowDropUpLineIcon";

interface PrizesProps {
  title?: string;
  images?: string[];
  default?: boolean;
  first?: boolean;
}

const Prizes: FC<PrizesProps> = ({
  title,
  images,
  first,
  default: _default,
}) => {
  const [open, setOpen] = useState(_default || false);

  return (
    <div
      className={`w-full p-[20px] flex flex-col gap-[20px] ${
        first ? "" : "border-t border-[#80839a80]"
      } `}
    >
      <div
        onClick={() => setOpen(!open)}
        className="flex justify-between items-center cursor-pointer"
      >
        <span className="text-[18px] text-bold text-gray-400">{title}</span>
        {open ? <ArrowDropUpLineIcon /> : <ArrowDropDownLineIcon />}
      </div>
      {open && (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 text-theme-grey">
          {(images || []).map((image) => (
            <div>
              <img src={image} alt="" className="rounded-lg" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Prizes;
