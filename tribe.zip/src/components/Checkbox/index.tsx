import React, { FC } from "react";

interface CheckboxProps {
  children?: any;
  selected?: boolean;
  onClick?: any;
  type?: "full" | "normal";
}

const Checkbox: FC<CheckboxProps> = ({
  children,
  selected,
  onClick,
  type = "normal",
}) => {
  return (
    <div
      onClick={onClick}
      className={`rounded-lg cursor-pointer border  h-[50px] flex items-center transition-all  gap-[20px] ${
        type === "full"
          ? "w-full justify-start px-[10px]"
          : " w-[50px] justify-center "
      }  ${
        selected
          ? "border-theme-red"
          : "border-theme-grey hover:border-theme-red"
      }`}
    >
      {children}
    </div>
  );
};

export default Checkbox;
