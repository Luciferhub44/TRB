import { useCallback } from "react";
import {
  ConnectorNotFoundError,
  SwitchChainNotSupportedError,
  useConnect,
  useDisconnect,
  useNetwork,
} from "wagmi";

const useAuth = () => {
  const { chain } = useNetwork();
  const { connectAsync, connectors } = useConnect();
  const { disconnectAsync } = useDisconnect();

  const login = useCallback(
    async (connectorID) => {
      const findConnector = connectors.find((c) => c.id === connectorID);
      try {
        const connected = await connectAsync({
          connector: findConnector,
          chainId: chain?.id,
        });
        if (!connected.chain.unsupported && connected.chain.id !== chain?.id) {
          throw new Error("Unsupported Chain");
        }
        return connected;
      } catch (error) {
        if (error instanceof ConnectorNotFoundError) {
          throw new Error("WalletConnectorNotFoundError");
        }
        if (error instanceof SwitchChainNotSupportedError) {
          throw new Error(
            "Unable to switch network. Please try it on your wallet"
          );
        }
      }
      return undefined;
    },
    [connectors, connectAsync, chain]
  );

  const logout = useCallback(async () => {
    try {
      await disconnectAsync();
    } catch (error) {
      console.error(error);
    } finally {
    }
  }, [disconnectAsync]);

  return { logout, login };
};

export default useAuth;
