export const NetworkContextName = "NETWORK";
export const connectorLocalStorageKey = "tribeNFTConnectorId";
