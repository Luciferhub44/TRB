import axios from "axios";
import { useEffect, useState } from "react";

const useCollectionState = () => {
  const [state, setState] = useState<any>();

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await axios.get(
          `https://api.opensea.io/api/v1/collection/tribe-odyssey/stats`,
          {
            headers: {
              "X-API-KEY": "3241c45055dd4d959fc0fce0fdc3211e",
            },
          }
        );
        if (res.status === 200) {
          setState(res.data.stats);
        }
      } catch (e) {
        console.log(e);
      }
    };

    fetch();
  }, []);

  return state;
};

export default useCollectionState;
