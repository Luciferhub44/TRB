import { useAccount, useNetwork } from "wagmi";
import {
  useConnectModal,
  useAccountModal,
  useChainModal,
} from "@rainbow-me/rainbowkit";
import { useEthersProvider, useEthersSigner } from "../utils/web3React";

export function useWeb3React() {
  const { chain } = useNetwork();
  const { address, connector, isConnected, isConnecting } = useAccount();
  const signer = useEthersSigner({ chainId: chain?.id });
  const provider = useEthersProvider({ chainId: chain?.id });

  return {
    chainId: chain?.id,
    account: isConnected ? address : null, // TODO: migrate using `isConnected` instead of account to check wallet auth
    isConnected,
    isConnecting,
    chain,
    connector,
    signer,
    provider,
  };
}

export function useWalletConnect() {
  const { openConnectModal } = useConnectModal();
  const { openAccountModal } = useAccountModal();
  const { openChainModal } = useChainModal();

  return {
    openConnectModal,
    openAccountModal,
    openChainModal,
  };
}
