import { FC, useContext, useEffect, useMemo, useState } from "react";
import Button from "../components/Button";
import Input from "../components/Input";
import GlobalContext from "../contexts/GlobalContext";
import SimpleBar from "simplebar-react";
import CheckboxCircleFillIcon from "remixicon-react/CheckboxCircleFillIcon";
import { useWeb3React } from "../hooks/useWeb3React";
import axios, { AxiosError } from "axios";
import { checkClaimed, checkExist, claim } from "../utils/contracts";
import { ClockLoader } from "react-spinners";
import { toast } from "react-toastify";
import useMint from "../hooks/useMint";

interface ClaimPageProps {}

interface CheckResult {
  id: string;
  claimed: boolean;
  exist: boolean;
  loading: boolean;
  error?: string;
}

const ClaimPage: FC<ClaimPageProps> = () => {
  const context: any = useContext(GlobalContext);
  const setState = context.setState;
  const toggleOpen = () => {
    setState((prevState: any) => ({ ...prevState, open: !prevState.open }));
  };

  const { account, signer } = useWeb3React();
  const { isClaimActive } = useMint(0);

  const [ids, setIds] = useState<number[]>([]);
  const [selected, setSelected] = useState<number[]>([]);
  const [claimed, setClaimed] = useState<number[]>([]);
  const [claiming, setClaiming] = useState(false);
  const [checkId, setCheckId] = useState(null);
  const [checkResult, setCheckResult] = useState<CheckResult>({
    id: "",
    claimed: false,
    exist: false,
    loading: false,
    error: undefined,
  });

  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const totalApes = useMemo(() => {
    return ids.length;
  }, [ids]);

  useEffect(() => {
    const fetch = async () => {
      axios
        .get(`https://api.0xapes.world/api/user/owned?address=${account}`)
        .then((res) => {
          const ids = (res.data.ids || []).map((id) => parseInt(id));
          setIds(ids);
          if (ids.length) {
            checkExist(ids)
              .then((res) => {
                setClaimed(res);
              })
              .catch(() => {});
          }
        })
        .catch((e: AxiosError) => {
          console.log(e.message);
        });
    };

    if (account) {
      fetch();
    } else {
      setIds([]);
      setClaimed([]);
    }
  }, [account, refreshTrigger]);

  const toggleSelected = (i: number) => {
    const isSelected = !!selected.find((el) => el === i);
    if (isSelected) {
      setSelected(selected.filter((el) => el !== i));
    } else {
      setSelected([...selected, i]);
    }
  };

  const selectAll = () => {
    setSelected(ids);
  };

  const onChangeCheckId = (e) => {
    setCheckId(e.target.value);
  };

  const onCheck = () => {
    const defaultState = {
      ...checkResult,
      loading: false,
      claimed: false,
      error: null,
      exist: false,
    };

    if (!checkId) {
      setCheckResult({
        ...defaultState,
        error: "Please input 0xApe Id to check!",
      });
      return;
    }
    const id = parseInt(checkId);
    if (isNaN(id) || !id) {
      setCheckResult({
        ...defaultState,
        error: "Please input valid 0xApe Id!",
      });
      return;
    }
    if (id < 10000 || id > 20145) {
      setCheckResult({ ...defaultState, error: `0xApe #${id} doesn't exist!` });
      return;
    }

    setCheckResult({ ...checkResult, loading: true });

    checkClaimed(id)
      .then((res) => {
        setCheckResult({
          ...checkResult,
          id: String(id),
          loading: false,
          claimed: res,
          error: undefined,
          exist: true,
        });
      })
      .catch(() => {
        setCheckResult({
          ...checkResult,
          id: String(id),
          loading: false,
          claimed: false,
          error: undefined,
          exist: true,
        });
      });
  };

  const onClaim = () => {
    if (!isClaimActive) {
      toast.error("Claim not started yet!");
      return;
    }
    if (!account) {
      toast.error("Please connect wallet to mint!");
      return;
    }
    if (selected.length === 0) {
      toast.error("Please select nfts that you want to claim!");
      return;
    }

    setClaiming(true);
    claim(selected, signer)
      .then((res) => {
        toast.success(
          `${selected.length} Tribe${
            selected.length > 1 ? "s" : ""
          } claimed successfully!`
        );
        setSelected([]);
      })
      .catch((error) => {
        toast.error((error as Error).message);
      })
      .finally(() => {
        setClaiming(false);
        setRefreshTrigger((prev) => prev + 1);
      });
  };

  return (
    <div className="flex gap-[80px] min-h-[600px] flex-col-reverse md:flex-row">
      <div className="flex-[6] border border-theme-grey rounded-lg p-[20px] claim-box">
        {account ? (
          <div className="h-full">
            <div className="p-[20px]">
              <h4 className="font-medium text-[20px] mb-6">
                Your 0xApes - ({totalApes} Total)
              </h4>
              <div className="flex justify-between">
                <span className="text-theme-grey">Select 0xApes to Claim</span>
                <span
                  onClick={selectAll}
                  className="text-theme-red cursor-pointer hover:opacity-70 transition-all"
                >
                  Select all
                </span>
              </div>
            </div>
            <div className="pr-[10px] relative claim-box-container">
              <div className="claim-box-gradient  h-full w-full absolute bottom-0 left-0 z-10 pointer-events-none"></div>
              <div className="w-full absolute bottom-0 left-0 z-10">
                {selected?.length > 0 && (
                  <div className="flex justify-between flex-col gap-4 pb-4  md:flex-row items-center px-5">
                    <p className="text-center md:text-right">
                      You selected {selected?.length} of {totalApes} Tribe
                    </p>
                    <div className="flex sm:gap-6 gap-3 flex-col sm:flex-row items-center ">
                      <span
                        onClick={() => setSelected([])}
                        className="text-theme-red cursor-pointer hover:opacity-70 transition-all"
                      >
                        Clear all
                      </span>
                      {claiming ? (
                        <Button>
                          <ClockLoader
                            color={"#ffffff"}
                            loading={true}
                            size={20}
                          />
                        </Button>
                      ) : (
                        <Button onClick={onClaim}>Claim Selected</Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
              <SimpleBar
                autoHide={false}
                className="p-[20px] pr-[10px]"
                style={{ maxHeight: 460, width: "100%" }}
              >
                <div className="grid grid-cols-3 md:grid-cols-5  gap-[20px]">
                  {[...ids].map((id, i) => {
                    const isSelected = !!selected.find((el) => el === id);
                    const isClaimed = !!claimed.find((el) => el === id);

                    return (
                      <div
                        onClick={() => {
                          if (!isClaimed) toggleSelected(id);
                        }}
                        className={`hover:opacity-80 relative cursor-pointer rounded-lg overflow-hidden ${
                          isSelected ? "border-theme-red border-[3px]" : ""
                        }`}
                        key={i}
                      >
                        {isClaimed && (
                          <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-20 flex items-center justify-center">
                            <CheckboxCircleFillIcon className="text-theme-green" />
                          </div>
                        )}
                        {isSelected && (
                          <div className="absolute top-0 left-0 w-full h-full bg-black bg-opacity-60 flex items-center justify-center">
                            <CheckboxCircleFillIcon className="text-theme-red" />
                          </div>
                        )}
                        <div>
                          <img
                            src={`https://cdn.0xworld.io/0xworld-ape-images/${id}.png`}
                            alt="0xape"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="h-full"></div>
              </SimpleBar>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full">
            <p className="mb-[40px]">
              To claim you need to connect your wallet.
            </p>
            <Button onClick={toggleOpen}>Connect Wallet</Button>
          </div>
        )}
      </div>
      <div className="flex-[4]">
        <h4 className="font-medium text-[20px] mb-8">
          Check 0xApes to Tribe claim
        </h4>
        <div className="flex gap-[20px] mb-4">
          <Input
            placeholder="Token ID #"
            value={checkId || undefined}
            onChange={onChangeCheckId}
          />
          {checkResult && checkResult.loading ? (
            <Button>
              <ClockLoader color={"#ffffff"} loading={true} size={20} />
            </Button>
          ) : (
            <Button onClick={onCheck}>Check</Button>
          )}
        </div>

        {checkResult && (
          <div>
            {checkResult.loading ? (
              <p className="mb-4">Checking...</p>
            ) : checkResult.error ? (
              <p className="mb-4">
                <span className="text-theme-red">{checkResult.error}</span>
              </p>
            ) : checkResult.claimed && checkResult.exist ? (
              <p className="mb-4">
                0xApe #{checkResult.id} has been{" "}
                <span className="text-theme-red">claimed</span>
              </p>
            ) : !checkResult.claimed && checkResult.exist ? (
              <p className="mb-4">
                0xApe #{checkResult.id}{" "}
                <span className="text-theme-red">not claimed yet</span>
              </p>
            ) : (
              <p className="mb-4">Please input 0xApe Id to check</p>
            )}

            {checkResult.exist && !checkResult.error && (
              <div>
                <img
                  src={`https://cdn.0xworld.io/0xworld-ape-images/${checkResult.id}.png`}
                  alt=""
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ClaimPage;
