import React, { FC, useEffect, useState } from "react";
import ReactPlayer from "react-player";
import styled from "styled-components";
import { createGlobalStyle } from "styled-components";
import Grid from "@mui/material/Grid";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Button } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  ArrowSmallIcon,
  QuoteIcon,
} from "../assets/icons";
import Slider from "react-slick";
import useCollectionState from "../hooks/useCollectionState";
import { ShortenText, sortAndSetCategory, ToText } from "../utils/helper";

const GlobalStyle = createGlobalStyle`
  .mainlayout {
   max-width:unset;
   margin:0;
   padding-left:0;
   padding-right:0;
  }
  .layout{
    max-width:1000px;
    @media screen and (max-width: 600px) {
        max-width:100vw;
    }
  }
body{
  font-family: "ManRope", sans-serif;
}
`;

interface IndexPageProps {}
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <div>{children}</div>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const HomePage: FC<IndexPageProps> = () => {
  const layoutdimensions = "layout max-w-[1200px] mr-auto ml-auto px-[20px] ";
  const [value, setValue] = React.useState(0);
  const [sec4slide, setSec4slide] = React.useState(
    "https://cdn.0xworld.io/tribe-images/373.png"
  );
  const [sec41slide, setSec41slide] = React.useState(0);

  const handleslidesec4 = (current) => {
    let imgscr = document
      .getElementsByClassName("carouselsec4")[0]
      .querySelectorAll(`[data-index="${current}"]`)[0]
      .querySelectorAll(`img`)[0].src;

    setSec4slide(imgscr);
    setSec41slide(current || 0);
  };
  var settingsec4 = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    focusOnSelect: true,
    // @ts-ignore
    afterChange: (current, next) => handleslidesec4(current),
    nextArrow: (
      <div className="slickrightarrow">
        <ArrowRightIcon />
      </div>
    ),
    prevArrow: (
      <div className="slickleftarrow">
        <ArrowLeftIcon />
      </div>
    ),
    responsive: [
      {
        breakpoint: 1100,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };
  const [sec5slide, setSec5slide] = React.useState(
    "https://i.seadn.io/gae/U10DD22XIqfpP-BiAOcv5UOToLaMNZbJm_Q-N2nHKXDMsa5D-pHtUZaM7HE4oyc4uNc9j-GdudBaSC6lFwzcMZrpyYP0B0uvYZPw?auto=format&w=384"
  );
  const [sec51slide, setSec51slide] = React.useState(0);

  const handleslidesec5 = (current) => {
    let imgscr = document
      .getElementsByClassName("carouselsec5")[0]
      .querySelectorAll(`.slick-current`)[0]
      .querySelectorAll(`img`)[0].src;

    const index = document
      .getElementsByClassName("carouselsec5")[0]
      .querySelectorAll(`.slick-current`)[0]
      .getAttribute("data-index");

    setSec5slide(imgscr);
    setSec51slide(index ? +index : 0);
  };

  const [sec2currslide, setSec2currslide] = React.useState(1);
  const [sec2totalslide, setSec2totalslide] = React.useState(10);
  var settingsec2 = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    // @ts-ignore
    afterChange: (current, next) => handleslidesec2(current),
    nextArrow: (
      <div className="slickrightarrow">
        <ArrowRightIcon />
      </div>
    ),
    prevArrow: (
      <div className="slickleftarrow">
        <ArrowLeftIcon />
      </div>
    ),
  };

  const handleslidesec2 = (current) => {
    var currentslide = document
      .getElementsByClassName("carouselsec2")[0]
      .getElementsByClassName("slick-arrow")[0]
      .getAttribute("currentslide");
    var totalslide = document
      .getElementsByClassName("carouselsec2")[0]
      .getElementsByClassName("slick-arrow")[0]
      .getAttribute("slidecount");

    setSec2currslide(parseInt(currentslide || "0") + 1);
    setSec2totalslide(parseInt(totalslide || "0"));
  };

  const [sec3slide, setSec3slide] = React.useState(
    "https://cdn.0xworld.io/tribe-images/10014.png"
  );
  const [sec3currslide, setSec3currslide] = React.useState(1);
  const [sec3totalslide, setSec3totalslide] = React.useState(10);
  const slider3 = React.useRef(null);
  var settingsec3 = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    focusOnSelect: true,
    vertical: true,
    // @ts-ignore
    afterChange: (current, next) => handleslidesec3(current),
    responsive: [
      {
        breakpoint: 600,
        settings: {
          vertical: false,
          slidesToShow: 3,
        },
      },
    ],
  };

  const handleslidesec3 = (current) => {
    let imgscr = document
      .getElementsByClassName("carouselsec3")[0]
      .querySelectorAll(`.slick-current`)[0]
      .querySelectorAll(`img`)[0].src;
    var slickslide = document
      .getElementsByClassName("carouselsec3")[0]
      .getElementsByClassName("slick-slide");
    var clonedslide = document
      .getElementsByClassName("carouselsec3")[0]
      .getElementsByClassName("slick-cloned");

    let currentslide = document
      .getElementsByClassName("carouselsec3")[0]
      .querySelectorAll(`.slick-current`)[0]
      // @ts-ignore
      .getAttribute("data-index");

    setSec3slide(imgscr);
    setSec3currslide(parseInt(currentslide || "0") + 1);
    setSec3totalslide(slickslide.length - clonedslide.length);
  };

  var settingsec5 = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    focusOnSelect: true,
    // @ts-ignore
    afterChange: (current, next) => handleslidesec5(current),
    nextArrow: (
      <div className="slickrightarrow">
        <ArrowRightIcon />
      </div>
    ),
    prevArrow: (
      <div className="slickleftarrow">
        <ArrowLeftIcon />
      </div>
    ),
    responsive: [
      {
        breakpoint: 1100,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  var settingquote = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: (
      <div className="slickrightarrow">
        <ArrowRightIcon />
      </div>
    ),
    prevArrow: (
      <div className="slickleftarrow">
        <ArrowLeftIcon />
      </div>
    ),
  };
  var settingcarat = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 1,
    focusOnSelect: true,
    // @ts-ignore
    afterChange: (current, next) => handleslidecarat(current),
    nextArrow: (
      <div className="slickrightarrow">
        <ArrowRightIcon />
      </div>
    ),
    prevArrow: (
      <div className="slickleftarrow">
        <ArrowLeftIcon />
      </div>
    ),
    responsive: [
      {
        breakpoint: 1100,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 800,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  const [cartcurrslide, setCaratcurrslide] = React.useState(
    "https://cdn.0xworld.io/tribe-images/3103.png"
  );
  const [caratlightbox, setCaratlightbox] = React.useState(false);

  const handleslidecarat = (current) => {
    let imgscr = document
      .getElementsByClassName("carsouselcarat")[0]
      .querySelectorAll(`.slick-current`)[0]
      .querySelectorAll(`img`)[0].src;

    setCaratcurrslide(imgscr);
    //setCaratlightbox(true);
  };

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  const collectionState = useCollectionState();

  const [newsItems, setNewsItems] = useState<any[]>([]);
  const mediumUrl =
    "https://api.rss2json.com/v1/api.json?rss_url=https://medium.com/feed/@0xapenft";

  useEffect(() => {
    fetch(mediumUrl)
      .then((res) => res.json())
      .then((data) => {
        if (data.feed) {
          const {
            feed: { image, link },
            items,
          } = data || {};

          setNewsItems(items.slice(0, 3));
        }
      });
  }, []);

  return (
    <Wrapper>
      {caratlightbox && cartcurrslide && (
        <Lightbox
          mainSrc={cartcurrslide}
          mainSrcThumbnail={cartcurrslide}
          onCloseRequest={() => setCaratlightbox(false)}
        />
      )}

      <GlobalStyle />
      <Sec1>
        <div className={layoutdimensions}>
          <h1>
            Find your <span>tribe</span>
          </h1>
          <img src="./assets/home/banner.png" alt="" />
        </div>
      </Sec1>
      <Sec2>
        <div className={layoutdimensions}>
          <Grid container spacing={9} className="sec2grid">
            <Grid item xs={12} sm={7}>
              <h1>Welcome to Tribe ODYSSEY</h1>
              <h5>
                Welcome to the Tribe project, home of the highly popular 0xApes
                and Tribe Odyssey NFT collections.{" "}
              </h5>
              <p>
                The 0xApes and Tribe phenom has taken the digital collectibles
                space by storm inspiring a movement driven by the power of
                community, a community that has over 30,000 members and growing
                across all its social media platforms.
              </p>
            </Grid>
            <Grid
              item
              xs={12}
              sm={5}
              className="singlecarouselsec carouselsec2"
            >
              <Slider {...settingsec2}>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/1404.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/108.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/8998.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/4467.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/4054.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/3092.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/9212.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/2803.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/6260.png"
                    alt=""
                  />
                </div>
                <div>
                  <img
                    src="https://cdn.0xworld.io/tribe-images/923.png"
                    alt=""
                  />
                </div>
              </Slider>
              <div className="control">
                {/* {sec2currslide} / {sec2totalslide} */}
              </div>
            </Grid>
          </Grid>
        </div>
      </Sec2>
      <Sec3>
        <div className={layoutdimensions}>
          <Grid container spacing={9}>
            <Grid item xs={12} md={7}>
              <Grid container spacing={3} className="carouselsec3">
                <Grid item xs={12} sm={3} className="singlecarouselsec ">
                  {/* <img
                                        src="https://cdn.0xworld.io/tribe-images/5266.png"
                                        alt=""
                                    />
                                    <img
                                        src="https://cdn.0xworld.io/tribe-images/177.png"
                                        alt=""
                                    />
                                    <img
                                        src="https://cdn.0xworld.io/tribe-images/1697.png"
                                        alt=""
                                    /> */}
                  <Slider ref={slider3} {...settingsec3}>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/10014.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/4962.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/9988.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/7724.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/3891.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/8047.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/3984.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/1342.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/2820.png"
                        alt=""
                      />
                    </div>
                    <div>
                      <img
                        src="https://cdn.0xworld.io/tribe-images/9450.png"
                        alt=""
                      />
                    </div>
                  </Slider>
                </Grid>
                <Grid item xs={12} sm={9}>
                  <img src={sec3slide} alt="" />

                  <div className="control">
                    <div
                      className="slickleftarrow"
                      onClick={() => (slider3?.current as any)?.slickPrev()}
                    >
                      <ArrowLeftIcon />
                    </div>
                    <div>{/* {sec3currslide} / {sec3totalslide} */}</div>
                    <div
                      className="slickrightarrow"
                      onClick={() => (slider3?.current as any)?.slickNext()}
                    >
                      <ArrowRightIcon />
                    </div>
                  </div>
                </Grid>
              </Grid>
            </Grid>

            <Grid item xs={12} md={5}>
              <TabPanel value={value} index={0}>
                <h1>Tribe odyssey</h1>
                <h5>
                  A collection of 9400 badass and entirely original ape NFT
                  characters that live on the Ethereum Blockchain.
                </h5>
                <p>
                  The collection's lore is based in an alternate dimension.
                  Within this dimension exists a futuristic world, a harsh and
                  barren wasteland ruled by a tech advanced ape civilization.
                </p>
                <Button
                  variant="contained"
                  className=""
                  onClick={() => {
                    window.open(
                      "https://opensea.io/collection/tribe-odyssey",
                      "_blank"
                    );
                  }}
                >
                  View on Opensea
                </Button>
              </TabPanel>
            </Grid>
          </Grid>

          <div className="caratsec">
            <h5>24 CARAT APES</h5>
            <p>
              They sit now perched upon decaying thrones, their exquisite 24
              Carat fur shines vibrantly still like royal armor piercing the
              shadows of the world that once was. Unwavering in their belief
              they are Gods amongst apes. Their thirst to rule is relentless.
            </p>
            <Slider {...settingcarat} className="carsouselcarat">
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/3103.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/6316.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/7881.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/1726.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/9091.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/5922.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/7517.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/11924.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/10819.png"
                  alt=""
                />
              </div>
              <div>
                <img
                  src="https://cdn.0xworld.io/tribe-images/10305.png"
                  alt=""
                />
              </div>
            </Slider>
          </div>
        </div>
      </Sec3>
      <Sec5>
        <div className={layoutdimensions}>
          <Grid container spacing={9} className="topheading">
            <Grid item xs={12} md={3}>
              <img src="./assets/home/alliance.png" alt="" />
            </Grid>
            <Grid item xs={12} md={9}>
              <span>TRIBE ALLIANCE is an exclusive collection</span> of unique
              and individualized 1/1 digital art pieces created for specific and
              verified celebrities. Tribe Alliance is a separate but related
              collection to Tribe Odyssey and is part of the project’s celebrity
              network initiative.{" "}
              <a
                href="https://medium.com/@0xapenft/banana-update-9-c66889dab794"
                target="_blank"
                rel="noreferrer"
              >
                Learn more...
              </a>
            </Grid>
          </Grid>
          <Grid container spacing={0} className="gridrow">
            <Grid item xs={12} sm={5} className="leftgrid">
              <img src={`./assets/home/nfl/${sec51slide}.jpg`} alt="" />
            </Grid>
            <Grid item xs={12} sm={2}>
              <div className="smallarrow">
                <ArrowSmallIcon />
              </div>
            </Grid>

            <Grid item xs={12} sm={5} className="rightgrid">
              <img src={sec5slide} alt="" />
            </Grid>
          </Grid>
          <Slider {...settingsec5} className="carouselsec5">
            <div>
              <img
                src="https://i.seadn.io/gae/U10DD22XIqfpP-BiAOcv5UOToLaMNZbJm_Q-N2nHKXDMsa5D-pHtUZaM7HE4oyc4uNc9j-GdudBaSC6lFwzcMZrpyYP0B0uvYZPw?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">Verron Haynes</div>
            </div>
            <div>
              <img
                src="https://i.seadn.io/gae/lJ7Fh2mkntTiUwwRGNJ6u4UJWsfp94SGAkQGfrsotDv58wZTwTMbmeBsvqqmBxMC_9tXQTDEgYh393N4JoIot7gTEq0lhfNtrfno?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">Champ Bailey</div>
            </div>
            <div>
              <img
                src="https://i.seadn.io/gae/IaCOQry_f2popz16UGP7I7y3C0oCP6Y7UX0pSShH_foAgoUxY-j3-_m7zZECnf8NqfsjMPpPncaA_S5I9F_8zdaJylEK3x3tFWddDJg?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">Braxton Miller</div>
            </div>
            <div>
              <img
                src="https://i.seadn.io/gae/mAK_ZSSXYoyxY8JNgYSf387v9a64VfKkoJqSSIte3W4RNr3lXJ1dhfo9TqoIidcUBJdVyCCaVFvcSmrYZs47hR9CAkBpW8tlIigiBjE?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">D.J. Shockley</div>
            </div>
            <div>
              <img
                src="https://i.seadn.io/gae/YwLGqtP8qrMXnvIpSn6kcsfXjRmFj0SAIu7tOO89dYA-MeTU7HbSfn7lv2NJr9uCh8Eevt0TFnGh6BxBQuV93U8LXJ046-Bq6hTdbw?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">Druw Jones</div>
            </div>
            <div>
              <img
                src="https://i.seadn.io/gae/CgcoXwY3g9da6obPmtcoUP-5kpbUxN7HIYO5ngonNEvzR29wj9598ynRNM2JIGnW6QRq9r_VLKYn1fEY5O61LhOd-dZ3_kYUye4UXw?auto=format&w=384"
                alt=""
              />
              <div className="flex justify-center">Andruw Jones</div>
            </div>
          </Slider>
        </div>
      </Sec5>
      <Sec4>
        <div className={layoutdimensions}>
          <Grid container spacing={9} className="topheading">
            <Grid item xs={12} sm={3}>
              <img src="./assets/home/fighting.png" alt="" />
            </Grid>
            <Grid item xs={12} sm={9}>
              <span>The TRIBE FIGHTERS NETWORK</span> is an initiative that was
              launched by community legend{" "}
              <a
                href="https://twitter.com/USApe_12741"
                target="_blank"
                rel="noreferrer"
              >
                @USApe_12741
              </a>
              .Tribe Odyssey is now represented by an insane roster of some of
              the best up and coming international MMA fighters on both the
              professional and amateur circuit!{" "}
              <a
                href="https://medium.com/@0xapenft/banana-update-10-fa9083707cf9"
                target="_blank"
                rel="noreferrer"
              >
                Learn more...
              </a>
            </Grid>
          </Grid>
          <Grid container spacing={0} className="gridrow">
            <Grid item xs={12} sm={5} className="leftgrid">
              <img src={`./assets/home/fighter/${sec41slide}.png`} alt="" />
            </Grid>
            <Grid item xs={12} sm={2} className="leftgrid">
              <div className="smallarrow">
                <ArrowSmallIcon />
              </div>
            </Grid>
            <Grid item xs={12} sm={5} className="rightgrid">
              <img src={sec4slide} alt="" />
            </Grid>
          </Grid>

          <Slider {...settingsec4} className="carouselsec4">
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/373.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/lonestarkidmma"
                  target="_blank"
                  rel="noreferrer"
                >
                  Landry Ward
                </a>
              </div>
            </div>
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/9905.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/HelenPeralta123"
                  target="_blank"
                  rel="noreferrer"
                >
                  Helen Peralta
                </a>
              </div>
            </div>
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/10169.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/LoudColton"
                  target="_blank"
                  rel="noreferrer"
                >
                  Colton Loud
                </a>
              </div>
            </div>
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/11672.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/kasib_murdoch"
                  target="_blank"
                  rel="noreferrer"
                >
                  Kasib Murdoch
                </a>
              </div>
            </div>
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/5711.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/lildragonmma"
                  target="_blank"
                  rel="noreferrer"
                >
                  Kevin Fernandez
                </a>
              </div>
            </div>
            <div>
              <img src="https://cdn.0xworld.io/tribe-images/2055.png" alt="" />
              <div className="flex justify-center">
                <a
                  href="https://twitter.com/akmma_"
                  target="_blank"
                  rel="noreferrer"
                >
                  Austin Kolada
                </a>
              </div>
            </div>
          </Slider>
        </div>
      </Sec4>

      <Sec6>
        <div className={layoutdimensions}>
          <h1>Accomplishments</h1>

          <p>
            Tribe has never been bullish on laying out a “Road Map'' in the
            traditional sense. We’ve always, however, been in the mindset of
            striving towards consistency and completing and celebrating
            significant milestones and accomplishments. We build, we create, and
            we accomplish.
          </p>
          <Grid container spacing={3} className="cardOuter">
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/one.png" alt="" />
                <h2>
                  <a
                    href="https://apeshop.tribeodyssey.com/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    APE SHOP
                  </a>
                </h2>
                <p>
                  Creation of our very own native marketplace where both Tribe
                  and 0xApes can be bought, sold, and traded on a secure and
                  user-friendly platform with 0% fees
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/two.png" alt="" />
                <h2>
                  <a
                    href="https://medium.com/@0xapenft/banana-update-7-50cc48207cf4"
                    target="_blank"
                    rel="noreferrer"
                  >
                    TRIBE ODYSSEY
                  </a>
                </h2>
                <p>
                  Successful launch of the highly anticipated and entirely
                  original follow up collection to 0xApes.
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/three.png" alt="" />
                <h2>
                  <a
                    href="https://tribeodyssey.com/ens"
                    target="_blank"
                    rel="noreferrer"
                  >
                    ENS DOMAINS
                  </a>
                </h2>
                <p>
                  Tribe Odyssey has become part of the ENS takeover! Users who
                  hold a Tribe Odyssey NFT, can now register a unique
                  tribeodyssey.eth sub-domain.
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/four.png" alt="" />
                <h2>
                  <a
                    href="https://tribeodyssey.com/wallpaper"
                    target="_blank"
                    rel="noreferrer"
                  >
                    WALLPAPERS
                  </a>
                </h2>
                <p>
                  Introduction of the Wallpaper application where users are able
                  to update and customize their personal phone and desktop
                  wallpaper displays with their favorite Tribe apes!
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/five.png" alt="" />
                <h2>
                  <a
                    href="https://twitter.com/MinedPower/status/1554494687624544257?s=20&t=57XQ-rXSRXskkzh1jc26GA"
                    target="_blank"
                    rel="noreferrer"
                  >
                    irl events
                  </a>
                </h2>
                <p>
                  We’ve held an IRL event in Nashville where Tribe holders and
                  family were able to network and socialise. We see this as an
                  important element to reward holders and spread project
                  awareness.
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/six.png" alt="" />
                <h2>
                  <a
                    href="https://opensea.io/collection/tribe-alliance"
                    target="_blank"
                    rel="noreferrer"
                  >
                    tribe alliance
                  </a>
                </h2>
                <p>
                  Successful creation and onboarding of celebrities through
                  Tribe Odysseys celebrity network initiative.
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/seven.png" alt="" />
                <h2>
                  <a
                    href="https://medium.com/@0xapenft/different-tribe-same-bloodline-c805546ef31d"
                    target="_blank"
                    rel="noreferrer"
                  >
                    0xApes
                  </a>
                </h2>
                <p>
                  Successful launch of a first of its kind and extremely popular
                  BAYC expansion project in the NFT space.
                </p>
              </div>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <div className="crd">
                <img src="./assets/home/eight.png" alt="" />
                <h2>
                  <a
                    href="https://opensea.io/collection/19-the-exodus"
                    target="_blank"
                    rel="noreferrer"
                  >
                    19: The EXODUS
                  </a>
                </h2>
                <p>
                  Limited edition airdrop completed for select OG community
                  members featuring exclusive comic book cover artwork.
                </p>
              </div>
            </Grid>
          </Grid>
        </div>
      </Sec6>
      <Sec7>
        <div className={layoutdimensions}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={4}>
              <div className="leftstat">
                <h1>Overall Stats</h1>
              </div>
            </Grid>
            <Grid item xs={12} md={8} className="statOuter">
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6}>
                  <div className="statbx">
                    <h2>
                      {collectionState?.total_volume?.toFixed(1) || "0"} ETH
                    </h2>
                    <p>Total volume</p>
                  </div>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <div className="statbx">
                    <h2>
                      {collectionState?.floor_price?.toFixed(2) || "0"} ETH
                    </h2>
                    <p>floor price</p>
                  </div>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <div className="statbx">
                    <h2>{collectionState?.total_supply || "0"}</h2>
                    <p>Total Supply</p>
                  </div>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <div className="statbx">
                    <h2>{collectionState?.num_owners || "0"}</h2>
                    <p>owners</p>
                  </div>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </div>
      </Sec7>
      <Sec8>
        <div className={layoutdimensions}>
          <h1>Latest News</h1>

          <Grid container spacing={3} className="cardOuter newsOuter">
            {newsItems.map((item, i) => (
              <Grid item xs={12} md={4} key={i}>
                <div className="crd">
                  <img src={item.thumbnail} alt="" />
                  <h2>{item.title}</h2>
                  <p>{`${ShortenText(ToText(item.content), 0, 120)}...`}</p>
                  <Button
                    variant="contained"
                    className=""
                    onClick={() => {
                      window.open(item.link, "_blank");
                    }}
                  >
                    Read more
                  </Button>
                </div>
              </Grid>
            ))}
          </Grid>
        </div>
      </Sec8>

      <Sec9>
        <div className={layoutdimensions}>
          <ReactPlayer
            muted
            playing
            controls
            playIcon={<div className="w-[30px] h-[30px] bg-white">Hi</div>}
            width="100%"
            height={"400px"}
            url="https://vimeo.com/725852569"
          />
        </div>
      </Sec9>
      <Sec10>
        <div className={layoutdimensions}>
          <Slider {...settingquote}>
            <div className="quotebx">
              <QuoteIcon />
              <div className="txt">
                Just want to give a shout out to the very first project that
                open their arms and gave me great welcome! @0xapes @tribeodyssey
                still bullish on them #Tribe #rideordie 2023 will be a great
                year for the most amazing communities.
              </div>
              <a
                className="usrbx"
                href="https://twitter.com/Red_X1111"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbs.twimg.com/profile_images/1680761386765262849/xI72WrWR_400x400.jpg"
                  alt=""
                  style={{ borderRadius: "50%" }}
                />
                <div className="rght">
                  <h3>Red11.eth</h3>
                  <h6>@Red_X1111</h6>
                </div>
              </a>
            </div>
            <div className="quotebx">
              <QuoteIcon />
              <div className="txt">
                Feeling blessed to join the #TRIBE community and be part of the
                revolution. Excited to learn and grow with y’all. LFG!. Shout
                out to @volcanobl4ck @tribeodyssey
              </div>
              <a
                className="usrbx"
                href="https://twitter.com/OSCOofficial"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbs.twimg.com/profile_images/1616138749389176835/sxBmb337_normal.jpg"
                  alt=""
                  style={{ borderRadius: "50%" }}
                />
                <div className="rght">
                  <h3>OSCO</h3>
                  <h6>@OSCOofficial</h6>
                </div>
              </a>
            </div>
            <div className="quotebx">
              <QuoteIcon />
              <div className="txt">
                Wow just recently joined tribe and they are already the 2nd
                biggest community in my following 😅 @goblnnft you were right
                the notifications went crazy haha loving the vibe so far
                @tribeodyssey 👊 🟥
              </div>
              <a
                className="usrbx"
                href="https://twitter.com/AltJaqen"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbs.twimg.com/profile_images/1658106750116020224/Ezb4yFpe_400x400.png"
                  alt=""
                  style={{ borderRadius: "50%" }}
                />
                <div className="rght">
                  <h3>Altcoin Jaqen 🟥 👣 🍕</h3>
                  <h6>@AltJaqen</h6>
                </div>
              </a>
            </div>
            <div className="quotebx">
              <QuoteIcon />
              <div className="txt">
                If you want a long term stable project with ELITE 4k NFT’s just
                check out @tribeodyssey . They have been around for a long time
                and will continue to be. Everything they have come out with is
                TOP quality. The family is great and everyone fits in. 🟥🍌🦧❤️
              </div>
              <a
                className="usrbx"
                href="https://twitter.com/CoinsCrazy"
                target="_blank"
                rel="noreferrer"
              >
                <img
                  src="https://pbs.twimg.com/profile_images/1614401851541037056/tP6n6Nv3_normal.jpg"
                  alt=""
                  style={{ borderRadius: "50%" }}
                />
                <div className="rght">
                  <h3>CrazyCrypto 🏴‍☠️ #TRIBΞ</h3>
                  <h6>@CoinsCrazy</h6>
                </div>
              </a>
            </div>
          </Slider>
        </div>
      </Sec10>
      <Sec11>
        <div className={layoutdimensions}>
          <h1>Faq</h1>
          <Grid container spacing={3} className="cardOuter faq">
            <Grid item xs={12} md={6}>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel1aacc-content`}
                  id={`panel1aacc-header`}
                >
                  <Typography>What is an NFT?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <>
                      <div>
                        TLDR: Digital collectable that you can keep, sell, trade
                        etc. Think of a trading card that only you own, but
                        digital, as an example.
                        <br />
                        <br />
                      </div>
                      <div>
                        Officially: <br />A non-fungible token (NFT) is a unique
                        digital identifier that cannot be copied, substituted,
                        or subdivided, that is recorded in a blockchain, and
                        that is used to certify authenticity and ownership. The
                        ownership of an NFT is recorded in the blockchain and
                        can be transferred by the owner, allowing NFTs to be
                        sold and traded.
                      </div>
                    </>
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel2aacc-content`}
                  id={`panel2aacc-header`}
                >
                  <Typography>How do I buy Tribe NFT?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      You can buy a tribe NFT on our own marketplace (
                      <a
                        href="https://apeshop.tribeodyssey.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-blue-500"
                      >
                        https://apeshop.tribeodyssey.com
                      </a>
                      ), or other third party marketplaces such as:
                      <br />
                      <br />
                    </div>
                    <a
                      href="https://opensea.io/collection/tribe-odyssey"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500"
                    >
                      Opensea
                    </a>{" "}
                    <br />
                    <a
                      href="https://looksrare.org/collections/0x77F649385cA963859693C3d3299D36dfC7324EB9"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500"
                    >
                      LooksRare
                    </a>
                    <br />
                    <a
                      href="https://x2y2.io/collection/tribe-odyssey/items"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500"
                    >
                      X2Y2
                    </a>
                    <br />
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel3aacc-content`}
                  id={`panel3aacc-header`}
                >
                  <Typography>How do I join TRIBE Discord server?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      Click the discord link below - simple.
                      <br />
                      <br />
                    </div>
                    <a
                      href="https://opensea.io/collection/tribe-odyssey"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500"
                    >
                      https://discord.gg/AfymTZDXN9
                    </a>{" "}
                    <br />
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel4aacc-content`}
                  id={`panel4aacc-header`}
                >
                  <Typography>
                    How do I download 4K resolution of my TRIBE?
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      You can navigate the site, go to Assets, 4K Tribe, enter
                      your asset number and hit download.
                      <br />
                      <br />
                      Or click{" "}
                      <a
                        href="https://tribeodyssey.com/4ktribe"
                        target="_blank"
                        rel="noreferrer"
                        className="text-blue-500"
                      >
                        here
                      </a>{" "}
                      to skip the navigation bit and get that sweet, sweet 4K
                      goodness.
                    </div>{" "}
                    <br />
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel5aacc-content`}
                  id={`panel5aacc-header`}
                >
                  <Typography>Does TRIBE have its own marketplace?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      YES SER!
                      <br />
                      <br />
                      Or click{" "}
                      <a
                        href="https://apeshop.tribeodyssey.com/"
                        target="_blank"
                        rel="noreferrer"
                        className="text-blue-500"
                      >
                        https://apeshop.tribeodyssey.com/
                      </a>{" "}
                      <br />
                      Buy, sell and trade your Tribe assets on our very own
                      dedicated, stand-alone marketplace that has been built on
                      the Ethereum blockchain. For a limited time, marketplace
                      fees have been reduced to 0%! (transaction fees still
                      apply)
                    </div>{" "}
                    <br />
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>
            <Grid item xs={12} md={6}>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel1aacc-content`}
                  id={`panel1aacc-header`}
                >
                  <Typography>How do I check rarity of TRIBE?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      Every single Tribe asset is a unique piece that has no
                      equal within or outside the collection. As such, we would
                      argue every single tribe is a perfect piece and should be
                      purchased on how the art identifies with you.{" "}
                    </div>
                    <div>
                      Of course, if you still want to buy what is regarded as a
                      “rarer” piece, you can check rarity at:
                    </div>
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel2aacc-content`}
                  id={`panel2aacc-header`}
                >
                  <Typography>
                    What are the benefits of holding TRIBE NFT?
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    <div>
                      You mean aside from a kick-ass 4k PFP? Being part of one
                      of the best communities out there? A founding team that
                      has continued to build regardless of market or FUD?
                    </div>
                    <br />
                    <br />
                    <div>Well we have:</div>
                    <br />
                    <div>Our Own proprietary marketplace</div>
                    <div>Merch to purchase (Coming Soon)</div>
                    <div>Tribefest (Community managed get togethers)</div>
                    <div>
                      Online community events (Poker, giveaways, competitions)
                    </div>
                    <div>Community run spaces</div>
                    <div>Banana brew pre workout on market</div>
                    <br />
                    <div>And much more. </div>
                    <div>
                      All contained and communicated out in medium articles to
                      you, the holders!
                    </div>
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel3aacc-content`}
                  id={`panel3aacc-header`}
                >
                  <Typography>
                    How do I get connected with my TRIBE on Twitter?
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Just follow the Tribe account on{" "}
                    <a
                      href="https://twitter.com/tribeodyssey"
                      target="_blank"
                      rel="noreferrer"
                      className="text-blue-500"
                    >
                      twitter
                    </a>
                    , and connect with the rest of us. It won’t take long to see
                    why we are regarded as one of the strongest online
                    communities out there.
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel4aacc-content`}
                  id={`panel4aacc-header`}
                >
                  <Typography>
                    How is TRIBE different from other NFT projects?
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    One of the few ethereum projects to continue its survival
                    through the crypto-winter and still going strong, we have
                    consistently delivered value to our holders.
                    <br />
                    <br />
                    We no longer provide a traditional “Road Map'' - web3 moves
                    quick, we try to move quicker. As such we look to add value
                    organically, working with partners and vendors to ensure
                    consistent delivery of features and value.
                  </Typography>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls={`panel5aacc-content`}
                  id={`panel5aacc-header`}
                >
                  <Typography>What is the total supply?</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>
                    Tribe was a claimed NFT with a limited mint window that
                    followed it. As such there are only 9401 Tribe NFT in
                    existence. <br /> <br /> The Mint window will NEVER be
                    opened again, and no further tribe claims can be completed.
                    The scarcity can not change.
                  </Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>
          </Grid>
        </div>
      </Sec11>
    </Wrapper>
  );
};

const Sec1 = styled.section`
  padding-top: 50px !important;
  h1 {
    font-weight: 800;
    font-size: 120px;
    text-transform: uppercase;
    text-align: Center;
    border-bottom: 2px solid #494a5a;
    padding-bottom: 10px;
    span {
      color: #b91d1d;
    }
  }
  img {
    margin-top: 40px;
    width: 100%;
  }
  @media screen and (max-width: 600px) {
    h1 {
      font-size: 60px;
    }
  }
`;
const Sec2 = styled.section`
  background: #000000;
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    margin: 0;
  }
  h5 {
    color: #fff;
    margin: 16px 0 20px 0;
  }
  p {
    color: #80839a;
  }
  img {
    margin-top: 0px;
    width: 100%;
    border-radius: 16px;
  }
  // .carouselsec2 {
  //     display: none;
  // }
`;
const Sec3 = styled.section`
  background: linear-gradient(90deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    margin: 0;
  }
  h5 {
    color: #fff;
    margin: 8px 0 20px 0;
  }
  p {
    color: #80839a;
  }
  img {
    margin-top: 0px;
    width: 100%;
    border-radius: 16px;
  }
  .carouselsec3 {
    .control {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 14px;
      div {
        margin: 0 8px;
        cursor: pointer;
      }
    }
  }

  // .threecol {
  //     img {
  //         margin-bottom: 24px;
  //     }
  //     @media screen and (max-width: 600px) {
  //         display: flex;

  //         img {
  //             margin: 0;
  //             width: 33%;
  //             padding: 10px;
  //             box-sizing: border-box;
  //         }
  //     }
  // }
  .MuiButton-contained {
    background: #b91d1d;
    border-radius: 6px;
    margin-top: 10px;
    text-transform: none;
  }
  .MuiTabs-root {
    margin-bottom: 24px;
    .MuiTabs-flexContainer {
      border-bottom: 2px solid rgba(128, 131, 154, 0.5);
      width: 100%;
    }
    .MuiButtonBase-root {
      color: #fff;
      width: 50%;
    }
    .MuiTabs-indicator {
      background: #b91d1d;
    }
  }
  .caratsec {
    margin-top: 30px !important;
    .carsouselcarat {
      .slick-slide {
        cursor: pointer;
      }
    }
    h5 {
      font-weight: 800;
      font-size: 28px;
      margin-bottom: 10px !important;
    }
    p {
      font-weight: 400;
      font-size: 15px;
      color: #fff;
      margin-bottom: 20px;
    }
    .slick-slide {
      img {
        padding: 10px;
      }
    }
  }
  .slick-slide {
    padding: 10px;
    .flex {
      margin-top: 7px;
    }
    img {
      padding: 0 !important;
      border: 2px solid transparent;
    }
    &.slick-current {
      img {
        border-color: #02feb2;
      }
    }
  }
`;
const Sec4 = styled.section`
  background: linear-gradient(90deg, #0d0c12 0%, #0d0c12 100%);
  position: relative;
  .smallarrow {
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: Center;
    height: 100%;
    @media screen and (max-width: 600px) {
      height: 100px;
      transform: rotate(90deg);
    }
  }
  .slick-slide {
    img {
      padding: 10px;
    }
  }

  .slick-slide {
    padding: 10px;
    .flex {
      margin-top: 7px;
    }
    img {
      padding: 0;
      border: 2px solid transparent;
    }
    &.slick-current {
      img {
        border-color: #02feb2;
      }
    }
  }

  .carousel {
    position: Static;
  }
  .carousel-slider {
    position: relative;
  }
  .thumbs-wrapper {
    position: absolute;
    left: 0;
    margin: 0;
    margin-top: 40px;
    width: 100%;
    .thumb {
      border-radius: 16px;
      border: 2px solid transparent;
      padding: 0;
      // width: 130px !important;
      img {
        // &::after {
        //     content: attr(data-width);
        // }
        width: 100%;
        height: 100%;
      }
      &.selected {
        border: 2px solid #fff;
        filter: drop-shadow(0px 0px 2px rgba(0, 255, 209, 0.5));
      }
    }
  }
  .layout {
    position: Relative;
  }
  .gridrow {
    padding-bottom: 100px;
    position: relative;
  }
  .topheading {
    margin-bottom: 50px;
    img {
      height: 60px;
      width: auto;
    }
    color: #80839a;
    span {
      color: #fff;
    }
    a {
      color: #b91d1d;
    }
  }
  h1 {
    font-weight: 800;
    font-size: 40px;
    text-transform: uppercase;
    margin: 0;
  }
  h5 {
    color: #fff;
    margin: 16px 0 20px 0;
  }
  p {
    color: #80839a;
  }
  img {
    margin-top: 0px;
    width: 100%;
    border-radius: 16px;
  }
`;
const Sec5 = styled(Sec4)`
  background: linear-gradient(90deg, #152331 0%, #000000 100%);
`;
const Sec6 = styled.section`
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    text-align: center;
    margin: 0;
    margin-bottom: 20px;
  }
  p {
    color: #80839a;
    text-align: center;
    margin-bottom: 0px !important;
  }
  // .MuiGrid-container {
  //     margin-top: 20px !important;
  // }
  .MuiGrid-item {
    box-sizing: border-box !important;
    margin-top: 14px !important;
  }
  .crd {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    text-align: center;
    background: #222129;
    border: 1px solid rgba(128, 131, 154, 0.5);
    border-radius: 16px;
    height: 100%;
    padding: 30px 18px;

    h2 {
      margin: 12px 0;
      font-weight: 700;
      font-size: 18px;
      text-transform: uppercase;
    }
    img {
      max-width: 100px;
      display: block;
      margin: 0 auto;
      margin-bottom: 14px;
    }
  }
`;
const Sec7 = styled.section`
  background: linear-gradient(90deg, #0f0c29 0%, #302b63 50%, #24243e 100%);
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    text-align: center;
    margin: 0;
    margin-bottom: 20px;
  }
  p {
    color: #80839a;
    text-align: center;
    margin-bottom: 24px !important;
  }

  .MuiGrid-item {
    box-sizing: border-box !important;
    margin-top: 14px !important;
  }
  .leftstat {
    h1 {
      color: #ffffff;
      text-align: left;
      font-weight: 800;
      font-size: 40px;
      @media screen and (max-width: 500px) {
        font-size: 27px;
      }
      @media screen and (max-width: 900px) {
        text-align: center;
      }
    }
    p {
      color: #80839a;
      text-align: left;
    }
  }
  .statbx {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    text-align: center;
    background: #0f0c27;
    border: 1px solid rgba(128, 131, 154, 0.5);
    border-radius: 16px;
    height: 100%;
    padding: 18px;

    h2 {
      margin: 0;
      font-weight: 700;
      font-size: 28px;
      text-transform: uppercase;
    }
    p {
      margin-bottom: 0px !important;
      margin-top: 6px;
      text-transform: uppercase;
      font-size: 16px;
      font-weight: 600;
    }
    img {
      max-width: 100px;
      display: block;
      margin: 0 auto;
      margin-bottom: 14px;
    }
  }
`;
const Sec8 = styled.section`
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    text-align: center;
    margin: 0;
    margin-bottom: 20px;
  }
  p {
    color: #80839a;
    text-align: center;
    margin-bottom: 24px !important;
  }
  // .MuiGrid-container {
  //     margin-top: 20px !important;
  // }
  .MuiGrid-item {
    box-sizing: border-box !important;
    margin-top: 14px !important;
  }
  .crd {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    text-align: left;
    background: #222129;
    border: 1px solid rgba(128, 131, 154, 0.5);
    border-radius: 16px;
    height: 100%;
    padding: 18px;

    h2 {
      margin: 12px 0;
      font-weight: 700;
      font-size: 18px;
      text-transform: uppercase;
    }
    img {
      width: 100%;
      display: block;
      margin: 0 auto;
      margin-bottom: 14px;
    }
    p {
      text-align: left;
      margin-bottom: 8px !important;
    }
    .MuiButton-contained {
      background: #b91d1d;
      border-radius: 6px;
      margin-top: 10px;
      width: 100%;
      text-transform: capitalize;
    }
  }
`;
const Sec9 = styled.section`
  background: linear-gradient(90deg, #232526 0%, #414345 100%);
`;
const Sec10 = styled.section`
  .quotebx {
    svg {
      opacity: 0.2;
      margin: auto;
      transform: scale(0.8);
      transform-origin: top center;
      margin-bottom: 30px;
    }
  }
  .txt {
    max-width: 600px;
    margin: auto;
  }
  .usrbx {
    display: flex;
    align-items: center;
    margin: auto;
    width: max-content;
    margin-top: 40px;
    img {
      height: 60px;
      width: 60px;
      margin-right: 14px;
    }
    .rght {
      h3 {
        font-weight: 800;
        font-size: 20px;
        text-align: left;
      }
      h6 {
        font-weight: 400;
        font-size: 14px;
        color: #80839a;
        text-align: left;
      }
    }
  }
`;
const Sec11 = styled.section`
  background: linear-gradient(90deg, #152331 0%, #000000 100%);
  h1 {
    font-weight: 800;
    font-size: 40px;
    @media screen and (max-width: 500px) {
      font-size: 27px;
    }
    text-transform: uppercase;
    text-align: center;
    margin: 0;
    margin-bottom: 20px;
  }

  .MuiGrid-item {
    box-sizing: border-box !important;
    margin-top: 14px !important;
  }
  .MuiAccordion-root {
    background: rgba(62, 33, 96, 0) !important;
    border: 1px solid rgba(128, 131, 154, 0.5) !important;
    border-radius: 8px !important;
    color: #fff !important;
    margin-bottom: 14px;
    svg {
      path {
        fill: #fff;
      }
    }
    .MuiAccordionSummary-content {
      .MuiTypography-root {
        color: #fff;
      }
    }
  }
`;
const Wrapper = styled.div`
  .layout {
    padding: 0;
  }
  .singlecarouselsec {
    .control {
      text-align: center;
      margin-top: 6px;
    }
    .carouselsec4 {
      .slick-slider {
        .slick-slide {
          img {
            padding: 0px !important;
          }
        }
      }
    }
    @media screen and (max-width: 800px) {
      .carouselsec5,
      .carouselsec4,
      .carsouselcarat {
        .slick-arrow {
          z-index: 99 !important;
          &.slick-prev {
            left: 0;
            transform: translateX(-20px) scale(0.7);
          }
          &.slick-next {
            right: 0;
            transform: translateX(20px) scale(0.7);
          }
        }
      }
    }

    section {
      // margin-bottom: 170px;
      padding: 100px 0;
      @media screen and (max-width: 1100px) {
        padding: 100px 50px;
      }
    }
  }
  section {
    // margin-bottom: 170px;
    padding: 100px 0;
    @media screen and (max-width: 1100px) {
      padding: 100px 50px;
    }
  }
  .control-arrow {
    background: transparent !important;
  }

  @media screen and (min-width: 1100px) {
    .MuiGrid-root {
      padding-top: 0 !important;
      margin-top: 0 !important;
    }
  }
  .topheading {
    @media screen and (max-width: 900px) {
      .MuiGrid-grid-md-9 {
        padding-top: 30px !important;
      }
      .MuiGrid-grid-sm-9 {
        padding-top: 30px !important;
      }
    }
  }

  .cardOuter {
    margin-top: 30px !important;
    .MuiGrid-root {
      margin-top: 20px !important;
    }
  }
  .faq {
    @media screen and (max-width: 900px) {
      .MuiGrid-grid-md-6 {
        margin-top: 0 !important;
        padding-top: 0px !important;
      }
      .MuiGrid-grid-sm-6 {
        margin-top: 0 !important;
        padding-top: 00px !important;
      }
    }
  }
  .statOuter {
    .MuiGrid-root {
      margin-bottom: 20px !important;
    }
  }
  .slick-slider {
    .slick-slide {
      max-width: 100vw;
      img {
        padding: 10px;
        max-width: 100vw;
      }
    }
    .slick-slider {
      .slick-slide {
        img {
          padding: 10px;
          max-width: 100vw;
        }
      }
      @media screen and (max-width: 1100px) {
        padding: 0 61px;
        .slick-prev {
          left: 20px;
        }
        .slick-next {
          right: 20px;
        }
      }
      @media screen and (max-width: 900px) {
        padding: 0 0px;
      }
    }
    @media screen and (max-width: 900px) {
      padding: 0 0px;
    }
  }
  .slickrightarrow {
  }
  .slick-arrow {
    &::before {
      display: none;
    }
    &.slick-prev {
      margin-left: -14px;
    }
  }
`;

export default HomePage;
