import React, { FC } from "react";
import Disclose from "../components/Disclose";

interface FAQPageProps {}

const FAQPage: FC<FAQPageProps> = () => {
  return (
    <div className="max-w-[900px] mx-auto">
      <h1 className="font-bold text-[20px] text-center mb-[50px]">
        Frequently Asked Questions
      </h1>
      <div className="flex flex-col gap-[20px]">
        <Disclose
          title={"On what network is TRIBE available?"}
          body={`The Ethereum Blockchain.`}
        />
        <Disclose
          title={"Is there a public mint?"}
          body={`An Additional 3854 unique Tribe apes will be released for public sale.`}
        />
        <Disclose
          title={"What is the mint price?"}
          body={`Existing 0xApes holders who were captured in the snapshot can mint for 0.15Eth during public sale. Standard public sale mint cost will be 0.2Eth`}
        />
        <Disclose title={"What is the total supply?"} body={`14,000`} />
        <Disclose
          title={"Which wallets will be supported?"}
          body={`Ethereum compatible Wallets such as Metamask and Trust Wallet will be supported.`}
        />
        <Disclose
          title={"Can 0xGenesis holders claim TRIBE?"}
          body={`No,if you are trying to claim TRIBE and are currently holding a Genesis 0xape you will need to migrate it to the Trilogy collection for eligibility to claim. You can find out how to migrate your Genesis 0xApe(s) by checking out the Migration guide channel in discord.`}
        />
        <Disclose
          title={"How long will the claim window be open for 0xApes holders?"}
          body={`The window to claim your TRIBE apes will be open indefinitely`}
        />
        <Disclose
          title={"Is TRIBE an instant reveal?"}
          body={`Tribe will not be instant reveal. Once claimed/minted Tribe NFTs will appear in the form of placeholders for an undisclosed period.`}
        />
        <Disclose
          title={"On what marketplaces will TRIBE be tradable?"}
          body={`You can BUY, SELL and BID on TRIBE Apes within our very own in-built standalone marketplace, Opensea, LooksRare & X2Y2`}
        />
        <Disclose
          title={"Do the creators receive a royalty?"}
          body={`Each transaction related to the buying and selling of 0xApes will incur a 5% creator royalty.`}
        />
      </div>
    </div>
  );
};

export default FAQPage;
