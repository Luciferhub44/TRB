import { FC } from "react";
import Prizes from "../components/Prizes";
import {
  longerList,
  prizeTitles,
  shorterList,
} from "../config/constants/prizes";

interface PrizesPageProps {}

const PrizesPage: FC<PrizesPageProps> = () => {
  return (
    <div className="flex flex-col items-center gap-[80px]">
      <div className="flex flex-col gap-[40px] max-w-[1200px] mx-auto w-full">
        <p className="text-center font-bold text-[20px] tracking-widest">
          Pool Prizes
        </p>
        {/* <p className="text-center text-theme-grey mx-auto">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry.
        </p> */}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 auto-cols-auto">
          <div className="flex  flex-col border border-[#80839a80] rounded-lg p-[0px] pool-back">
            <p className="p-[16px] text-[22px] tracking-wide border-b border-[#80839a80]">
              Pool 1 (60 Days)
            </p>
            <div className="overflow-y-auto h-[550px]">
              <div className="flex gap-[0px] flex-col p-[0px]">
                {prizeTitles["shorter"].map(([key, title], index) => (
                  <Prizes
                    title={title}
                    images={shorterList[key].map(
                      (name) =>
                        `https://cdn.0xworld.io/tribe-prizes/shorter/${key}/${name}`
                    )}
                    first={index === 0}
                    key={key}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex  flex-col border border-[#80839a80] rounded-lg p-[0px] pool-back">
            <p className="p-[16px] text-[22px] tracking-wide border-b border-[#80839a80]">
              Pool 2 (90 Days)
            </p>
            <div className="overflow-y-auto h-[550px]">
              <div className="flex gap-[0px] flex-col p-[0px]">
                {prizeTitles["longer"].map(([key, title], index) => (
                  <Prizes
                    title={title}
                    images={longerList[key].map(
                      (name) =>
                        `https://cdn.0xworld.io/tribe-prizes/longer/${key}/${name}`
                    )}
                    first={index === 0}
                    key={key}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrizesPage;
