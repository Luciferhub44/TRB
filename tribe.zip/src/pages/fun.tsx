import { FC, useState } from "react";
import axios from "axios";
import fileDownload from "js-file-download";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";

interface FunPageProps {}

const FunPage: FC<FunPageProps> = () => {
  const [iptvalue, setIptvalue] = useState(0);
  const [id, setId] = useState(0);
  const [images, setImages] = useState<string[]>([]);
  const [index, setIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const [trigger, setTrigger] = useState(0);

  const handleChangeId = (e) => {
    let amount = parseInt(e.target.value);
    setIptvalue(amount);
  };

  const handleView = () => {
    setId(iptvalue);
    setIndex(0);
    setImages([`https://cdn.0xworld.io/tribe-images-hr/${iptvalue}.png`]);
    setOpen(true);
  };

  const handleDownload = () => {
    axios
      .get(`https://cdn.0xworld.io/tribe-images-hr/${iptvalue}.png`, {
        responseType: "blob",
      })
      .then((res) => {
        fileDownload(res.data, `tribe-hr-${id}.png`);
      });
  };

  const onImageLoad = () => {
    setTrigger(Date.now());
  };

  return (
    <div className="flex flex-col items-center gap-[80px]">
      <div className="h-[80px] text-3xl">
        <h1 className="text-xl mb-8">Tribe Digital Assets</h1>
      </div>
      <div className=" text-center flex flex-col gap-[50px] max-w-[800px] mx-auto">
        <div className="cntnt">
          <div className="bx ">
            <h5 className="text-2xl">Your Tribe</h5>
          </div>
          <div className="flex mt-5 gap-[8px]">
            <div className="flex">
              <input
                className="h-[50px] rounded-lg border border-theme-grey w-full bg-transparent outline-none text-white px-4 hover:border-[#E5E5E5] focus:border-[#E5E5E5]"
                type="number"
                value={iptvalue}
                placeholder="0000"
                onChange={handleChangeId}
              />
            </div>
            <button
              className="transition-all rounded-md h-[50px] flex justify-center items-center px-[20px] bg-[#B91D1D] hover:bg-[#961616] active:bg-[#870505] "
              onClick={() => handleView()}
            >
              View
            </button>
            <button
              className="transition-all rounded-md h-[50px] flex justify-center items-center px-[20px] bg-[#FFF] text-red-500"
              onClick={() => handleDownload()}
            >
              Download
            </button>
          </div>
        </div>

        {open && (
          <Lightbox
            mainSrc={images[index]}
            nextSrc={images[(index + 1) % images.length]}
            prevSrc={images[(index + images.length - 1) % images.length]}
            onCloseRequest={() => setOpen(false)}
            onMovePrevRequest={() =>
              setIndex((index + images.length - 1) % images.length)
            }
            onMoveNextRequest={() => setIndex((index + 1) % images.length)}
            onImageLoad={onImageLoad}
          />
        )}
      </div>
    </div>
  );
};

export default FunPage;
