import React, { FC, useEffect, useState } from "react";
import Audio from "../components/Audio";
import { useWeb3React } from "../hooks/useWeb3React";
import { toast } from "react-toastify";
import { lookup, register } from "../utils/contracts";
import { normalize } from "@ensdomains/eth-ens-namehash";
import TwitterFillIcon from "remixicon-react/TwitterFillIcon";
import { title } from "process";

interface BeatsPageProps {}

const BeatsPage: FC<BeatsPageProps> = () => {
  const { account, signer } = useWeb3React();
  const [loading, setLoading] = useState(false);

  const files = [
    {
      title: "Tribe Evolution",
      src: "./music/TRIBE_Evolution_ringtone (2).mp3",
    },
    {
      title: "Shaman",
      src: "./music/Shamen_Ringtone (2).mp3",
    },
    {
      title: "Forest Dweller",
      src: "./music/Forest_Dweller_Ringtone (2).mp3",
    },
  ];
  const [subdomain, setSubdomain] = useState("");

  const [resolvedDomain, setResolvedDomain] = useState(null);

  useEffect(() => {
    if (account) {
      lookup(account).then((res) => {
        setResolvedDomain(res);
      });
    }
  }, [account]);

  const onChangeSubdomain = (domain) => {
    setSubdomain(normalize((domain || "").toLowerCase().trim()));
  };

  const onRegister = async () => {
    if (!account) {
      toast.error("Please connect wallet to register!");
      return;
    }
    if (!subdomain) {
      toast.error("Please input your subdomain name!");
      return;
    }

    setLoading(true);
    register(subdomain, signer)
      .then((res) => {
        toast.success(`${subdomain}.tribeodyssey.eth registered successfully!`);
        setSubdomain("");
      })
      .catch((error) => {
        toast.error((error as Error).message);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <div className="flex flex-col items-center gap-[80px]">
      <div className=" text-center flex flex-col gap-[40px] max-w-[800px] mx-auto items-center">
        <p>
          Thanks to Leeroy, reppin’ Tribe just got even easier with the
          legendary musician and DJ (The Prodigy) creating some badass custom
          Tribal ringtones for our entire community to enjoy!
        </p>

        <div className="flex justify-center">
          <a
            className="flex hover:text-theme-red"
            href="https://twitter.com/leeroythornhill"
            target="_blank"
          >
            Follow Leeroy{"  "}
            <TwitterFillIcon className="ml-2" />
          </a>
        </div>

        {files.map((file) => (
          <Audio title={file.title} src={file.src} key={file.title} />
        ))}
      </div>
    </div>
  );
};

export default BeatsPage;
