import React, { FC, useEffect, useState } from "react";
import { ClockLoader } from "react-spinners";
import Button from "../components/Button";
import QuestionLineIcon from "remixicon-react/QuestionLineIcon";
import { styled } from "@mui/material";
import Tooltip, { TooltipProps, tooltipClasses } from "@mui/material/Tooltip";
import { useWeb3React } from "../hooks/useWeb3React";
import { toast } from "react-toastify";
import { lookup, register } from "../utils/contracts";
import { normalize } from "@ensdomains/eth-ens-namehash";

const HtmlTooltip = styled(({ className, ...props }: TooltipProps) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    background: "linear-gradient(180deg, #14121b 0%, #000000 100%)",
    border: "1px solid rgba(128, 131, 154, 0.5)",
    borderRadius: "6px",
    innerWidth: "215px",
  },
}));

interface EnsPageProps {}

const EnsPage: FC<EnsPageProps> = () => {
  const { account, signer } = useWeb3React();
  const [loading, setLoading] = useState(false);
  const [subdomain, setSubdomain] = useState("");

  const [resolvedDomain, setResolvedDomain] = useState(null);

  useEffect(() => {
    if (account) {
      lookup(account).then((res) => {
        setResolvedDomain(res);
      });
    }
  }, [account]);

  const onChangeSubdomain = (domain) => {
    setSubdomain(normalize((domain || "").toLowerCase().trim()));
  };

  const onRegister = async () => {
    if (!account) {
      toast.error("Please connect wallet to register!");
      return;
    }
    if (!subdomain) {
      toast.error("Please input your subdomain name!");
      return;
    }

    setLoading(true);
    register(subdomain, signer)
      .then((res) => {
        toast.success(`${subdomain}.tribeodyssey.eth registered successfully!`);
        setSubdomain("");
      })
      .catch((error) => {
        toast.error((error as Error).message);
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <div className="flex flex-col items-center gap-[80px]">
      <div className=" text-center flex flex-col gap-[40px] max-w-[800px] mx-auto">
        <p>
          Tribe Odyssey has become part of the ENS takeover! Users who hold a
          Tribe Odyssey NFT, can now register a unique tribeodyssey.eth{" "}
          <span className="text-theme-red">(Just pay gas!)</span>
        </p>
        <p className="text-theme-grey">
          We look forward to seeing our loyal community repping their new and
          unique Tribe Odyssey subdomains and embracing the ENS revolution!
        </p>

        <div className="flex justify-center">
          <HtmlTooltip
            title={
              <React.Fragment>
                <div className="ens-faq">
                  <h6 className="mb-1">FAQ</h6>
                  <p>1. Connect your wallet</p> <p>2. Input your ENS name</p>{" "}
                  <p>3. Push register</p>{" "}
                  <p>4. You will be required to be pay gas fees</p>{" "}
                  <p>5. You may register 1 ENS per wallet address</p>
                </div>
              </React.Fragment>
            }
            placement="right-start"
          >
            <p className="flex hover:text-theme-red">
              How it works?{"  "}
              <QuestionLineIcon className="ml-2" />
            </p>
          </HtmlTooltip>
        </div>

        <div className="flex items-center gap-[20px] sm:flex-row flex-col border border-[#80839a80] rounded-lg p-[40px] ens-box-gradient">
          <input
            className="h-[50px] rounded-lg border border-[#80839a80] w-full bg-transparent outline-none text-white px-4 hover:border-[#E5E5E5] focus:border-[#E5E5E5] ens-box-gradient"
            type="text"
            placeholder="Your domain name"
            value={subdomain}
            onChange={(e) => {
              onChangeSubdomain(e.target.value);
            }}
          />
          <span className="font-bold text-[20px]">.tribeodyssey.eth</span>
          {loading ? (
            <Button>
              <ClockLoader color={"#ffffff"} loading={true} size={20} />
            </Button>
          ) : (
            <Button disabled={!subdomain} onClick={onRegister}>
              Register
            </Button>
          )}
        </div>

        <div className="flex justify-center">
          <a
            className="font-bold text-[14px]"
            href="https://www.one37pm.com/nft/what-is-a-ens-subdomain/amp"
            target="_blank"
            rel="noreferrer"
          >
            For more information about ENS subdomains click{" "}
            <span className="text-theme-red text-[16px]">here.</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default EnsPage;
