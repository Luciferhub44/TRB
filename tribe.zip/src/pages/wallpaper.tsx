import React, { FC } from "react";
import styled from "styled-components";
import Slider from "@mui/material/Slider";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import Switch from "@mui/material/Switch";
import { styled as muistyled } from "@mui/material/styles";
import CircularProgress from "@mui/material/CircularProgress";
import {
  BatteryIcon,
  CellularIcon,
  LockIcon,
  PreviewIcon,
  WallpaperIcon,
  WifiIcon,
} from "../assets/icons";
import date from "date-and-time";
const { loadImage } = require("canvas");

interface AboutPageProps {}

const AntSwitch = muistyled(Switch)(({ theme }) => ({
  width: 28,
  height: 16,
  padding: 0,
  display: "flex",
  "&:active": {
    "& .MuiSwitch-thumb": {
      width: 15,
    },
    "& .MuiSwitch-switchBase.Mui-checked": {
      transform: "translateX(9px)",
    },
  },
  "& .MuiSwitch-switchBase": {
    padding: 2,
    "&.Mui-checked": {
      transform: "translateX(12px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        opacity: 1,
        backgroundColor: theme.palette.mode === "dark" ? "#B91D1D" : "#B91D1D",
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxShadow: "0 2px 4px 0 rgb(0 35 11 / 20%)",
    width: 12,
    height: 12,
    borderRadius: 6,
    transition: theme.transitions.create(["width"], {
      duration: 200,
    }),
  },
  "& .MuiSwitch-track": {
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: "#B91D1D",
    boxSizing: "border-box",
  },
}));

const WallpaperPage: FC<AboutPageProps> = () => {
  const canvasRef = React.useRef(null);
  let scale = 10;
  const [imgslidvalue, setImgslidvalue] = React.useState(100);
  const [logodxslidvalue, setLogodxslidvalue] = React.useState(100);
  const [logodyslidvalue, setLogodyslidvalue] = React.useState(100);
  const [ctx, setCtx] = React.useState<any>(null);
  const [canvasdimns, setCanvasdimns] = React.useState({
    width: 282,
    height: 611,
  });
  const [imgdimns, setImgdimns] = React.useState(240 * scale * 0.75);
  const [loader, setLoader] = React.useState(false);
  const [logodimns, setLogodimns] = React.useState(118 * scale * 0.75);
  //const [imgurl,setImgurl] =  React.useState("../assets/monkey.png");

  const [ddselected, setDdselected] = React.useState("1");
  const [switchchecked, setSwitchchecked] = React.useState(false);
  const [inputchange, setInputchange] = React.useState<any>(null);
  const [bannerimage, setBannerimage] = React.useState<any>(null);
  const [logoimageblack, setLogoimageblack] = React.useState<any>(null);
  const [logoimagered, setLogoimagered] = React.useState<any>(null);
  const [logoimagewhite, setLogoimagewhite] = React.useState<any>(null);
  const [imageLoaded, setImageLoaded] = React.useState(false);

  // let variableimage;

  //imgbanner.crossOrigin = 'Anonymous';

  function handleapeidChange(event) {
    setInputchange(event.target.value);
  }

  let logoaspectratio = 118 / 46;
  let imagedx = 0,
    imagedy = 0,
    logodx = 0,
    logodyfixpos,
    logody = 0;
  // let image = new Image();

  const handlelogoChange = (event: SelectChangeEvent) => {
    setDdselected(event.target.value as string);
  };

  const handleChange = (event: Event, newValue: number | number[]) => {
    if (typeof newValue === "number") {
      setImgslidvalue(newValue);
    }
  };
  const handlelogodxChange = (event: Event, newValue: number | number[]) => {
    if (typeof newValue === "number") {
      setLogodxslidvalue(newValue);
    }
  };
  const handlelogodyChange = (event: Event, newValue: number | number[]) => {
    if (typeof newValue === "number") {
      setLogodyslidvalue(newValue);
    }
  };
  const handleswitchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSwitchchecked(event.target.checked);
  };
  let canvas;

  const updatecanvas = async () => {
    canvas = canvasRef.current;

    // for setting canvas width and height
    canvas.width = canvasdimns.width;
    canvas.height = canvasdimns.height;

    //setting canvas background

    ctx.fillStyle = "#111014";

    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // for bg image
    let imagesize;

    // for calculating the image position from top and to align it in centerl
    if (!switchchecked) {
      imagesize = imgdimns + imgslidvalue * scale * 1.2;
      imagedx = (canvasdimns.width - imagesize) / 2;
    } else {
      imagesize = imgdimns + imgslidvalue * scale * 0.8;
      imagedx = 0;
    }

    imagedy = canvasdimns.height - imagesize;
    if (inputchange) {
      if (bannerimage) {
        // ctx.drawImage(bannerimage, 0, 0);
        ctx.drawImage(
          bannerimage,
          0,
          0,
          canvasdimns.width * Math.pow(scale, 3),
          canvasdimns.height * Math.pow(scale, 3)
        );
        ctx.drawImage(bannerimage, imagedx, imagedy, imagesize, imagesize);
      }
    } else {
      loadImage(require("../assets/dummy.png").default).then((image) => {
        // setImgslidvalue(100);
        ctx.drawImage(image, imagedx, imagedy, imagesize, imagesize);
        // setLoader(false)
      });
    }

    // for logo

    let logosize;

    // for calculating the image position from top and to align it in centerl

    if (!switchchecked) {
      logodyfixpos = 180 * scale;
      logosize = logodimns + logodxslidvalue * scale * 0.8;
      logodx = (canvasdimns.width - logosize) / 2;
      logody = logodyfixpos + logodyslidvalue * scale * 0.7;
    } else {
      logodyfixpos = 338 * scale;
      logosize = logodimns + logodxslidvalue * scale * 0.4;
      logodx = canvasdimns.width - logosize - 400;
      logody = logodyfixpos - logodyslidvalue * scale * 0.7;
    }
    // logody = 200;

    //setting url of bg image and updating it

    if (ddselected !== "1") {
      if (ddselected == "2") {
        ctx.drawImage(
          logoimagewhite,
          logodx,
          logody,
          logosize,
          logosize / logoaspectratio
        );
      } else if (ddselected == "3") {
        ctx.drawImage(
          logoimageblack,
          logodx,
          logody,
          logosize,
          logosize / logoaspectratio
        );
      } else if (ddselected == "4") {
        ctx.drawImage(
          logoimagered,
          logodx,
          logody,
          logosize,
          logosize / logoaspectratio
        );
      }
    }
  };

  React.useEffect(() => {
    if (canvasRef.current) {
      if ((canvasRef.current as HTMLCanvasElement).getContext("2d"))
        setCtx((canvasRef.current as HTMLCanvasElement).getContext("2d"));
      if (ctx) {
        requestAnimationFrame(updatecanvas);
      }
    }
  }, [canvasRef.current]);

  React.useEffect(() => {
    if (switchchecked) {
      setCanvasdimns({
        width: 543 * scale,
        height: 351 * scale,
      });
    } else {
      setCanvasdimns({
        width: 282 * scale,
        height: 611 * scale,
      });
    }
    setImgslidvalue(100);
    setLogodxslidvalue(100);
    setLogodyslidvalue(100);
  }, [switchchecked]);

  React.useEffect(() => {
    if (ctx) {
      if (!inputchange) {
        setDdselected("1");
      }

      updatecanvas();
    }
  }, [canvasdimns, imgslidvalue, logodxslidvalue, logodyslidvalue, ddselected]);

  const fetchPlus = (url, options = {}, retries) =>
    fetch(url, options)
      .then((res) => {
        if (res.ok) {
          return res;
        }
        if (retries > 0) {
          return fetchPlus(url, options, retries - 1);
        }
        throw new Error(res.statusText);
      })
      .catch((error) => console.error(error.message));

  const fetchimagebanner = () => {
    setImageLoaded(false);

    if (inputchange) {
      setLoader(true);
      let imageurl = `https://cdn.0xworld.io/tribe-images/${inputchange}.png`;
      fetchPlus(imageurl, {}, 3).then((item) => {
        const imgbanner = new Image();
        imgbanner.crossOrigin = "anonymous";
        imgbanner.src = item.url;
        imgbanner.onload = () => {
          setImageLoaded(true);
        };

        setBannerimage(imgbanner);
      });
    } else {
      setBannerimage(null);
    }
  };

  React.useEffect(() => {
    fetchimagebanner();
  }, [inputchange]);

  React.useEffect(() => {
    setTimeout(() => {
      if (ctx && imageLoaded && bannerimage) {
        setLoader(false);
        updatecanvas();
      }
    }, 1000);
  }, [bannerimage, imageLoaded]);

  React.useEffect(() => {
    loadImage(require("../assets/logoblack.png").default).then((image) => {
      setLogoimageblack(image);
    });
    loadImage(require("../assets/logored.png").default).then((image) => {
      setLogoimagered(image);
    });
    loadImage(require("../assets/logo.png").default).then((image) => {
      setLogoimagewhite(image);
    });
    document!.querySelector("canvas")!.style!.transform! = `scale(1/${scale})`;
  }, []);

  const createwallpaper = () => {
    var link = document.createElement("a");
    link.download = `tribe-${
      switchchecked ? "desktop" : "mobile"
    }-${inputchange}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  };
  const now = new Date();
  console.log(imgslidvalue);

  return (
    <div
      className="wallpaperpage flex gap-[80px] min-h-[600px] flex-col md:flex-row"
      style={{ alignItems: "stretch" }}
    >
      <LeftBx className="flex-[10] md:flex-[5] ">
        <div className="mb-8">Tribe NFT Wallpapers</div>
        <div id="imgtag"></div>
        <div className="border border-theme-grey rounded-lg p-[20px] claim-box">
          <div className="bx enterid">
            <h4 className="mb-6">Please enter your Tribe Ape ID:</h4>
            <input
              placeholder={"Tribe Ape Id"}
              onChange={handleapeidChange}
              type="text"
              className="h-[50px] rounded-lg border border-theme-grey w-full bg-transparent outline-none text-white px-4 hover:border-[#E5E5E5] focus:border-[#E5E5E5]"
            />
            {inputchange ? (
              <div className="logobximagescale">
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Logo</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={ddselected}
                    label="Age"
                    onChange={handlelogoChange}
                  >
                    <MenuItem value={1}>No logo</MenuItem>
                    <MenuItem value={2}>White Logo</MenuItem>
                    <MenuItem value={3}>Black Logo</MenuItem>
                    <MenuItem value={4}>Red Logo</MenuItem>
                  </Select>
                </FormControl>
                <div className="slidcontentbx">
                  <div className="labelheading">Image Size</div>
                  <div className="sliderslidbx">
                    <Slider
                      aria-label="Temperature"
                      value={imgslidvalue}
                      color="primary"
                      min={50}
                      max={200}
                      onChange={handleChange}
                    />
                    {imgslidvalue}%
                  </div>
                </div>
              </div>
            ) : null}
            {ddselected != "1" ? (
              <>
                <div className="slidcontentbx">
                  <div className="labelheading">Logo Scale</div>
                  <div className="sliderslidbx">
                    <Slider
                      aria-label="Temperature"
                      value={logodxslidvalue}
                      color="secondary"
                      min={50}
                      max={200}
                      onChange={handlelogodxChange}
                    />
                    {logodxslidvalue}%
                  </div>
                </div>
                <div className="slidcontentbx">
                  <div className="labelheading">Logo Position</div>
                  <div className="sliderslidbx">
                    <Slider
                      aria-label="Temperature"
                      value={logodyslidvalue}
                      color="secondary"
                      min={50}
                      max={200}
                      onChange={handlelogodyChange}
                    />
                    {logodyslidvalue}%
                  </div>
                </div>
              </>
            ) : null}
          </div>
          <div className="btmactionbutton">
            {loader ? (
              <button className="loader" disabled>
                <CircularProgress />
                Loading...
              </button>
            ) : !inputchange ? (
              <button>
                <PreviewIcon />
                Preview
              </button>
            ) : (
              <button onClick={() => createwallpaper()}>
                <WallpaperIcon />
                Create Wallpaper
              </button>
            )}
          </div>
        </div>
      </LeftBx>
      <RightBx
        className={`flex-[10] md:flex-[5]  ${
          switchchecked ? "desktop" : "mobile"
        }`}
      >
        <div className="switchOuter">
          <div className="label" style={{ opacity: !switchchecked ? 1 : 0.5 }}>
            Mobile
          </div>
          <AntSwitch
            checked={switchchecked}
            onChange={handleswitchChange}
            inputProps={{ "aria-label": "ant design" }}
          />
          <div className="label" style={{ opacity: switchchecked ? 1 : 0.5 }}>
            Desktop
          </div>
        </div>
        <div className="canvasmaskouter">
          <img
            src={require("../assets/masklap.png").default}
            alt=""
            className="mask laptop"
          />
          <img
            src={require("../assets/mask.png").default}
            alt=""
            className="mask mobile"
          />
          <div className="screenoverlay">
            <div className="screenconfig">
              <div className="sctime">{date.format(now, "hh:mm ")}</div>
              <div className="scright">
                <CellularIcon />
                <WifiIcon />
                <BatteryIcon />
              </div>
            </div>
            <div className="timestart">
              <div className="lockicon">
                <LockIcon />
              </div>
              <div className="livetime">{date.format(now, "hh:mm ")}</div>
              <div className="livedate">{date.format(now, "ddd, MMM DD")}</div>
            </div>
            {!inputchange ? (
              <div className="tribetext">
                Please enter your <br /> Tribe Ape Id
              </div>
            ) : null}
          </div>
          <div className="canvasmask">
            <canvas ref={canvasRef}>
              Your browser does not support the HTML canvas tag.
            </canvas>
          </div>
        </div>
      </RightBx>
      <img
        src={require("../assets/shapel.png").default}
        className="shapel"
        alt=""
      />
      <img
        src={require("../assets/shaper.png").default}
        className="shaper"
        alt=""
      />
    </div>
  );
};
const LeftBx = styled.div`
  border-right: 1px solid #4a4a5a;
  padding-right: 80px;
  padding-top: 50px;
  @media screen and (max-width: 768px) {
    padding-right: 0;
    border-right: 0;
    border-bottom: 1px solid #4a4a5a;
    padding-bottom: 80px;
  }
  .MuiSlider-rail,
  .MuiSlider-track,
  .MuiSlider-thumb {
    color: #fff;
  }
  .sliderslidbx {
    display: flex;
    align-items: center;
    .MuiSlider-root {
      margin-right: 12px;
    }
  }
  .labelheading {
    margin-bottom: 4px;
  }
  .MuiFormControl-root {
    * {
      color: #fff;
    }
    .MuiOutlinedInput-notchedOutline {
      border-color: rgba(255, 255, 255, 0.6);
      border-radius: 8px;
    }
    &:hover {
      .MuiOutlinedInput-notchedOutline {
        border-color: rgba(255, 255, 255, 1) !important;
      }
    }
  }
  .claim-box {
    min-height: unset;
  }
  .slidcontentbx {
    color: #fff;
    margin-left: 0px;
    box-sizing: border-box;
    margin-top: 12px;
  }
  .logobximagescale {
    display: flex;
    align-items: center;
    border-top: 1px dashed rgba(128, 131, 154, 0.5);
    margin-top: 20px;
    padding-top: 20px;
    .slidcontentbx {
      min-width: calc(50% - 30px);
      margin-left: 30px;
      margin-top: 0px;
    }
  }
  .btmactionbutton {
    margin-top: 20px;
    button {
      background: #b91d1d;
      border-radius: 6px;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 10px 0;
      svg {
        margin-right: 8px;
      }
    }
    .loader {
      opacity: 0.7;
      // pointer-events:none;
      cursor: not-allowed;
      .MuiCircularProgress-root {
        color: #fff;
        margin: -6px;
        margin-right: 5px;
        svg {
          margin: 0;
          transform: Scale(0.5);
        }
      }
    }
  }
  .textbtm {
    margin-top: 22px;
    color: #80839a;
  }
`;
const RightBx = styled.div`
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  padding-top: 50px;
  .screenoverlay {
    position: absolute;
    top: 0px;
    left: 0;
    width: calc(100% - 0px);
    padding: 15px 20px;
    z-index: 1;
    .screenconfig {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 10px;
      margin: 0 0px;
      padding-top: 2px;
      padding-left: 14px;
      font-family: "SF Pro Display", sans-serif;

      .scright {
        display: flex;
        align-items: center;
        margin-right: 0px;
        svg {
          margin: 0 0px;
          transform: Scale(0.7);
        }
      }
    }
    .timestart {
      margin-top: 30px;
      .lockicon {
        display: flex;
        justify-content: Center;
        svg {
          transform: scale(0.8);
        }
      }
      .livetime {
        font-size: 50px;
        font-weight: 200 !important;
        text-align: Center;
        font-family: "SF Pro Display", sans-serif;
      }
      .livedate {
        font-size: 18px;
        font-weight: 300 !important;
        margin-top: -10px;
        text-align: Center;
        font-family: "SF Pro Display", sans-serif;
      }
    }
    .tribetext {
      text-align: center;
      margin-top: 34px;
    }
  }
  .switchOuter {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
    .label {
      margin: 0 15px;
    }
  }
  .claim-box {
    min-height: unset;
  }
  .canvasmaskouter {
    background: #000;
    width: fit-content;
    padding: 10px;
    border-radius: 40px;
    position: Relative;
  }
  .canvasmask {
    width: fit-content;
    border-radius: 0px;
    overflow: hidden;
    canvas {
      width: 282px;
      height: 611px;
    }
  }
  .mask {
    position: absolute;
    width: 315px;
    max-width: unset;
    left: -6px;
    top: -4px;
  }
  .laptop {
    display: none;
  }

  &.desktop {
    .canvasmask {
      border-radius: 0;
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;

      overflow: hidden;
      canvas {
        width: 543px;
        height: 351px;
      }
    }
    .screenconfig,
    .timestart {
      display: none;
    }

    .laptop {
      display: block;
    }
    .mobile {
      display: none;
    }
    .mask {
      position: absolute;
      width: 660px;
      max-width: unset;
      left: -53px;
      top: -2px;
    }
    .canvasmaskouter {
      background: #000;
      width: fit-content;
      padding: 5px;
      border-radius: 0;
      border-top-left-radius: 12px;
      border-top-right-radius: 12px;
      position: Relative;
    }
  }
`;

export default WallpaperPage;
