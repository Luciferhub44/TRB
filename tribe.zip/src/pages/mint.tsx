import { FC, useContext, useMemo, useState } from "react";
import { ClockLoader } from "react-spinners";
import { toast } from "react-toastify";
import Button from "../components/Button";
import Checkbox from "../components/Checkbox";
import GlobalContext from "../contexts/GlobalContext";
import { useWeb3React } from "../hooks/useWeb3React";
import useMint from "../hooks/useMint";
import { useMintWindow } from "../hooks/useMintWindow";
import { mint } from "../utils/contracts";

interface MintPageProps {}

const MintPage: FC<MintPageProps> = () => {
  const context: any = useContext(GlobalContext);
  const setState = context.setState;

  const [count, setCount] = useState<any>(undefined);
  const [minting, setMinting] = useState<boolean>(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const { account, signer } = useWeb3React();
  const { costPerMint, available, isSaleActive } = useMint(refreshTrigger);
  const countDown = useMintWindow(1660608000, 1660694400);
  //const countDown = useMintWindow(1660521600, 1660608000);

  const toggleOpen = () => {
    setState((prevState: any) => ({ ...prevState, open: !prevState.open }));
  };

  const error = useMemo(() => {
    if (!isSaleActive) {
      return "Sale Paused!";
    } else if (available === 0) {
      return "Sold Out";
    } else if (!count) {
      return "Select";
    } else {
      return null;
    }
  }, [count, available, isSaleActive]);

  const handleMint = () => {
    if (!isSaleActive) {
      toast.error("Sale not started yet!");
      return;
    }
    if (!account) {
      toast.error("Please connect wallet to mint!");
      return;
    }
    if (count === 0) {
      toast.error("Please choose how many nft you want!");
      return;
    }

    setMinting(true);
    mint(count, signer)
      .then((res) => {
        toast.success(
          `${count} Tribe${count > 1 ? "s" : ""} minted successfully!`
        );
      })
      .catch((error) => {
        toast.error((error as Error).message);
      })
      .finally(() => {
        setMinting(false);
        setRefreshTrigger((prev) => prev + 1);
      });
  };

  return (
    <div className="flex flex-col items-center">
      <div className="max-w-[900px] mx-auto text-center mb-[50px]">
        <p className="mb-[50px]">
          In the shadows of a dystopian world that once was, a post-apocalyptic
          landscape is dotted with the remnants of a high tech and futuristic
          ape civilization. From the molten volcanic wastelands to the frosty
          glacial fringes, and the trippy watering holes poisoning the barren
          landscape between them. The 19 furs fight for the growth of their
          tribal kingdoms.
        </p>
        {countDown}
      </div>
      <div className="border border-theme-grey flex gap-[20px] items-center flex-col p-[20px] max-w-[700px] w-full rounded-lg">
        <h2 className="text-[20px] text-bold">Mint Tribe</h2>
        <div className="flex gap-[10px] sm:gap-[50px] flex-col sm:flex-row items-center">
          <div className="text-theme-grey">
            Price{" "}
            <span className="text-theme-red">
              {(parseFloat(costPerMint) * (count || 1)).toFixed(2)} ETH
            </span>
          </div>
          <div className="text-theme-grey">
            Max <span className="text-theme-red">5 per transaction</span>
          </div>
        </div>
        <div className="flex flex-col md:flex-row gap-[12px]">
          <div className="flex gap-[10px]">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <Checkbox
                  key={i}
                  selected={i + 1 === count}
                  onClick={() => setCount(i + 1)}
                >
                  {i + 1}
                </Checkbox>
              ))}
          </div>
          {account ? (
            minting ? (
              <Button>
                <ClockLoader color={"#ffffff"} loading={true} size={20} />
              </Button>
            ) : (
              <Button
                disabled={!!error}
                onClick={() => {
                  if (!error) handleMint();
                }}
              >
                {error ?? "Mint your NFT"}
              </Button>
            )
          ) : (
            <Button onClick={toggleOpen}>Connect Wallet</Button>
          )}
        </div>
        <div className="text-theme-grey">
          {available}/{3854}
        </div>
      </div>
    </div>
  );
};

export default MintPage;
