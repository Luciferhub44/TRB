import React, { FC, useEffect, useRef, useState } from "react";
import { ClockLoader } from "react-spinners";
import Button from "../components/Button";
import { toast } from "react-toastify";
import emailjs from "@emailjs/browser";
import ReCAPTCHA from "react-google-recaptcha";

interface CouncilPageProps {}

const CouncilPage: FC<CouncilPageProps> = () => {
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [concept, setConcept] = useState("");
  const [attach, setAttach] = useState(null);
  const [captcha, setCaptcha] = useState("");

  const form = useRef<HTMLFormElement | null>(null);
  useEffect(() => {
    form.current?.focus();
  }, []);

  const onRecaptchaChange = (value) => {
    setCaptcha(value);
  };

  const onSubmit = (e) => {
    e.preventDefault();

    setLoading(true);
    emailjs
      .sendForm(
        "service_9sfo5vf",
        "template_d83t77d",
        form.current!,
        "UXimPcFlxILXRd7SZ"
      )
      .then(
        (result) => {
          if (result.text === "OK")
            toast.success("Your message has been sent!");
          setConcept("");
          setAttach(null);
        },
        (error) => {
          console.log(error.text);
          toast.error(error.text);
        }
      )
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <div className="flex flex-col items-center gap-[80px]">
      <div className=" text-center flex flex-col gap-[40px] max-w-[800px] mx-auto">
        <div className="flex sm:flex-row flex-col items-center pb-[50px] border-b-2 border-[#80839a80]">
          <img
            src="../assets/c.png"
            alt="aa"
            className="w-[250px] mr-[20px] text-justify"
          />
          <p>
            Calling all Tribe virtuosos! Our community is a treasure trove of
            brilliance. Share your secret sauce for propelling us to new
            dimensions - because together, we're the architects of innovation!
          </p>
        </div>

        <form
          className="flex items-center gap-[20px] flex-col"
          ref={form}
          encType="multipart/form-data"
          method="post"
          onSubmit={onSubmit}
        >
          <div className="flex w-full mb-8">
            <div className="flex-none self-center  sm:w-[200px] w-[120px]">
              <label className="flex">
                <span className="text-gray-300 text-[14px]">Name*</span>
              </label>
            </div>
            <div className="grow">
              <input
                type="text"
                className="mt-1 block w-full sm:w-4/6 border rounded-[8px] text-black"
                placeholder=""
                name="user_name"
                required={true}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
          </div>
          <div className="flex w-full mb-8">
            <div className="flex-none self-center sm:w-[200px] w-[120px]">
              <label className="flex">
                <span className="text-gray-300 text-[14px]">
                  Contact (Twitter or Discord)*
                </span>
              </label>
            </div>
            <div className="grow">
              <input
                type="text"
                className="mt-1 block w-full sm:w-4/6 rounded-[8px] text-black"
                placeholder=""
                name="user_contact"
                required={true}
                value={contact}
                onChange={(e) => setContact(e.target.value)}
              />
            </div>
          </div>
          <div className="flex w-full mb-8">
            <div className="flex-none  sm:w-[200px] w-[120px]">
              <label className="flex">
                <span className="text-gray-300 text-[14px]">
                  Concept / Idea / Suggestions
                </span>
              </label>
            </div>
            <div className="grow">
              <textarea
                className="mt-1 block w-full rounded-[8px] text-black"
                placeholder=""
                name="user_message"
                rows={5}
                value={concept}
                onChange={(e) => setConcept(e.target.value)}
              />
              {/* <input
                type="file"
                className="mt-4 block w-full sm:w-4/6 rounded-[8px]"
                name="user_attach"
              /> */}
            </div>
          </div>
          <div className="flex w-fill mb-8 justify-center">
            <ReCAPTCHA
              sitekey="6LfhN3opAAAAAGXupg_djxnBhBsavGQXnUYH-hHg"
              onChange={onRecaptchaChange}
            />
          </div>
          <div className="flex w-full mb-8 justify-end">
            {loading ? (
              <Button>
                <ClockLoader color={"#ffffff"} loading={true} size={20} />
              </Button>
            ) : (
              <button
                className={`transition-all rounded-md h-[50px] flex justify-center items-center px-[20px] ${
                  !name || !contact
                    ? "bg-theme-grey cursor-not-allowed"
                    : "bg-[#B91D1D] hover:bg-[#961616] active:bg-[#870505]"
                }`}
                disabled={!name || !contact}
                type="submit"
              >
                Submit
              </button>
            )}
          </div>

          <div className="flex flex-col w-full mb-8 mt-12">
            <p className="text-red text-[24px]">
              Update: Exciting Contributions Pouring in for the Tribe Odyssey
              Council!
            </p>
            <p className="text-[18px] mt-4 text-left">
              Since the launch of the Tribe Odyssey The Council section on our
              website, we've been overwhelmed by the passionate response from
              our community members. It's been a whirlwind of creativity and
              inspiration as members from all corners of our Tribe have stepped
              up to contribute their suggestions and ideas!
            </p>
            <p className="text-[18px] mt-4 text-left">
              From innovative new expedition routes to unique community
              engagement initiatives, the suggestions pouring in have been
              nothing short of exhilarating. Our community's enthusiasm and
              dedication to shaping the future of our collective journey are
              truly remarkable!
            </p>
            <p className="text-[18px] mt-4 text-left">
              The Tribe Odyssey Council is buzzing with activity as our members
              continue to share their wisdom and vision for the future. Every
              suggestion is a testament to the boundless creativity and
              collaborative spirit that has, and always shall, define our Tribe.
            </p>
            <p className="text-[18px] mt-4 text-left">
              With this in mind, let’s take a look at the proposals that have
              been put forward over the past few weeks by our brilliant and
              innovative Tribal trailblazers (all The Council proposals shall
              remain anonymous):
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              1) Big Branding: Significant Partnerships/Sponsorships
            </p>
            <p className="text-[18px] mt-4 text-left">
              This would not only extend to web3 companies but sports
              leagues/teams/organizations. I know the ideas and can assist with
              bringing them to the team. This idea would not only help the
              project grow but would keep the project relevant.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              2) Remove the Tribe Odyssey Collection from OpenSea
            </p>
            <p className="text-[18px] mt-4 text-left">
              I believe that OpenSea has stopped creator support and therefore
              we should remove the collection from this marketplace. If this is
              a viable option, a community poll should be utilized to finalize
              this decision.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              3) Decrease the Supply and Increase Member Rewards
            </p>
            <p className="text-[18px] mt-4 text-left">
              Allow holders to burn Tribe Odyssey apes (ETH Chain) and reward
              them with Tribe Ordinals (BTC Chain). For example: Burn 25 Tribe
              Odyssey apes and give away 99 Tribe Ordinals apes. After the burn,
              the new supply will be 6923.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              4) Public Founder/Owner/Director
            </p>
            <p className="text-[18px] mt-4 text-left">
              Find a person that is 100% dedicated to the project and shows up
              on social media with his/her personal account.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              5) Involvement of Whales
            </p>
            <p className="text-[18px] mt-4 text-left">
              Create a chat with only Whales where the team's ideas will be
              heard first and opinions will be exchanged and discussed.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              6) Ordinals Hype
            </p>
            <p className="text-[18px] mt-4 text-left">
              Distribute more Tribe Ordinals for more volume on Magic Eden. For
              example: 1 Tribe Ordinal distributed for the top 100 Tribe Odyssey
              holders.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">7) Engagement</p>
            <p className="text-[18px] mt-4 text-left">
              Reward holders with NANA Points for posts, re-posts, and likes on
              X.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              8) FOMO Raffles
            </p>
            <p className="text-[18px] mt-4 text-left">
              Open up FOMO raffles for a limited time. For example: For one day
              only, but announced many days in advance.
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              9) Raffle Blue Chip/Upcoming Project NFTs{" "}
            </p>
            <p className="text-[18px] mt-4 text-left">
              Raffle some other upcoming/flying collections, For example: Lil
              Pudgys, in order to get more eyes on the Tribe Odyssey collection.
              This could provide some momentum and bring more buyers/kick start
              things again before the upcoming Bull run.{" "}
            </p>
            <p className="text-red text-[18px] mt-4 text-left">
              10) Establishing a DAO/Elected Council
            </p>
            <p className="text-[18px] mt-4 text-left">
              Handover Tribe Odyssey to the community! Given the profound
              enthusiasm and wealth of ideas/experience within our community,
              instituting a select Council comprised of community-elected
              members will pave the way for Tribe's continual growth and
              evolution. Empower the community!
            </p>
            <p className="text-[18px] mt-4 text-left">
              As we continue to gather and review the wealth of ideas being
              shared, we're excited to see how they will shape the next chapter
              of our journey together. Stay tuned for further updates as we work
              towards turning some of these exciting suggestions into reality!
            </p>
            <p className="text-[18px] mt-4 text-left">
              We want to extend our heartfelt thanks to each and every member
              who has taken the time to contribute. Your passion and dedication
              are the driving force behind our shared success, and we're
              incredibly grateful for your involvement.
            </p>
            <p className="text-[18px] mt-4 text-left">
              The Tribe has truly spoken, and we invite our passionate members
              to continue to contribute their ideas and suggestions towards the
              Tribe Odyssey: The Council page. Together, we will chart a course
              to new horizons and unlock the full potential of the Tribe Odyssey
              project.
            </p>
            <p className="text-[18px] mt-4 text-left">
              Thank you for being a part of this incredible journey!
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CouncilPage;
