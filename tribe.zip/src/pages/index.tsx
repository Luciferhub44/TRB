import React, { FC } from "react";
import ReactPlayer from "react-player";

interface IndexPageProps {}

const IndexPage: FC<IndexPageProps> = () => {
  return (
    <div>
      <div className="border border-[#80839a80] h-[300px] sm:h-[400px] md:h-[560px] rounded overflow-hidden bg-black">
        <ReactPlayer
          muted
          playing
          controls
          playIcon={<div className="w-[30px] h-[30px] bg-white">Hi</div>}
          width="100%"
          height={"100%"}
          url="https://vimeo.com/725852569"
        />
      </div>
    </div>
  );
};

export default IndexPage;
