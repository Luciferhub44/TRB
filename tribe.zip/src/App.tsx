import React, { FC } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Layout from "./components/Layout";
import AboutPage from "./pages/about";
import EnsPage from "./pages/ens";
import BeatsPage from "./pages/beats";
import CouncilPage from "./pages/council";
import FAQPage from "./pages/faq";
import FunPage from "./pages/fun";
import "simplebar/dist/simplebar.min.css";
import WallpaperPage from "./pages/wallpaper";
import HomePage from "./pages/home";
import ClaimPage from "./pages/claim";
import StakingPage from "./pages/staking";
import { useAxios } from "./hooks/useAxios";
import RafflePage from "./pages/raffles";
import RaffleOpenPage from "./pages/rafflesopened";
import RaffleWinnerPage from "./pages/rafflesadmin";
import ProfilePage from "./pages/profile";
import WinnersPage from "./pages/winners";

interface AppProps {}

const App: FC<AppProps> = () => {
  useAxios();

  return (
    <BrowserRouter>
      <Layout>
        <Switch>
          <Route exact path="/" component={HomePage} />
          <Route exact path="/about" component={AboutPage} />
          <Route exact path="/wallpaper" component={WallpaperPage} />
          <Route exact path="/ens" component={EnsPage} />
          <Route exact path="/beats" component={BeatsPage} />
          <Route exact path="/council" component={CouncilPage} />
          {/* <Route exact path="/mint" component={MintPage} /> */}
          <Route exact path="/faq" component={FAQPage} />
          <Route exact path="/4ktribe" component={FunPage} />
          <Route exact path="/claim" component={ClaimPage} />
          <Route exact path="/account" component={ProfilePage} />
          <Route exact path="/staking" component={StakingPage} />
          <Route exact path="/raffles" component={RafflePage} />
          <Route exact path="/winners" component={WinnersPage} />
          <Route exact path="/raffle/:id" component={RaffleOpenPage} />
          <Route exact path="/admin" component={RaffleWinnerPage} />
        </Switch>
      </Layout>
    </BrowserRouter>
  );
};

export default App;
