module.exports = {
  purge: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  darkMode: false, // or 'media' or 'class',
  mode: "jit",
  theme: {
    extend: {
      colors: {
        "theme-orange": "#FF512F",
        "theme-pink": "#DD2476",
        "theme-grey": "#80839A",
        "theme-red": "#B91D1D",
        "theme-dark": "#14121B",
        "theme-green": "#07bc0c",
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [require("@tailwindcss/forms")],
};
